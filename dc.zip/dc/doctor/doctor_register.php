<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Patient Registration</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<!-- BEGIN PLUGIN CSS -->
<link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="../assets/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="../assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/boostrap-checkbox/css/bootstrap-checkbox.css" rel="stylesheet" type="text/css" media="screen"/>
<link rel="stylesheet" href="../assets/plugins/ios-switch/ios7-switch.css" type="text/css" media="screen">
<!-- END PLUGIN CSS -->
<!-- BEGIN CORE CSS FRAMEWORK -->
<link href="../assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<!-- END CORE CSS FRAMEWORK -->
<!-- BEGIN CSS TEMPLATE -->
<link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
<!-- END CSS TEMPLATE -->
</head>
<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN HEADER -->
<?php include '../templates/header.php'; ?>
<!-- END HEADER --> 
<!-- BEGIN CONTAINER -->
<div class="page-container row"> 
  <!-- BEGIN SIDEBAR -->
  <?php include '../templates/sidebar.php'; ?>
  <a href="#" class="scrollup">Scroll</a>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    
    <div class="clearfix"></div>
    <div class="content">
        <div class="col-md-5">
			<ul class="breadcrumb">
				<li><p>Doctors</p></li>
				<li><a href="#" class="active">Doctor Registration</a> </li>
			</ul>
		</div>
		<div class="page-title col-md-7"> 
			<h3> <span class="semi-bold">Doctor Registration</span></h3>
		</div>  
	  <div class="row">
        <div class="col-md-12">
          <div class="grid simple transparent">
            <div class="grid-title">
              <h4>Basic <span class="semi-bold">Profile</span></h4>
              <div class="tools"> <a href="javascript:;" class="collapse"></a> <!--<a href="#grid-config" data-toggle="modal" class="config"></a> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> --></div>
            </div>
            <div class="grid-body ">
              <div class="row">
                <form id="doctor_profile_details" name="doctor_profile" action="" method="post">
                  <div id="rootwizard" class="col-md-12">
                    <div class="form-wizard-steps">
                      <ul class="wizard-steps">
                        <li class="" style="min-width:50%;" data-target="#step1"> <a href="#tab1" data-toggle="tab"> <span class="step">1</span> <span class="title">Basic & Consultation</span> </a> </li>
                        <li data-target="#step2" class=""> <a href="#tab2" data-toggle="tab"> <span class="step">2</span> <span class="title">Postal & Profile</span> </a> </li>
                       <!-- <li data-target="#step3" class=""> <a href="#tab3" data-toggle="tab"> <span class="step">3</span> <span class="title">User settings</span> </a> </li>
                        <li data-target="#step4" class=""> <a href="#tab4" data-toggle="tab"> <span class="step">4</span> <span class="title">Feedback <br>
                          </span> </a> </li>-->
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                    <div class="tab-content transparent">
                      <div class="tab-pane" id="tab1"> <br>
						<div class="row column-seperation">
                <div class="col-md-6">
                  <h4>Basic Info</h4>            
                    <div class="row form-row">
                      <div class="col-md-5">
                        <input name="form3FirstName" id="d_firstname" type="text"  class="form-control" placeholder="First Name">
                      </div>
                      <div class="col-md-7">
                        <input name="form3LastName" id="d_lastname" type="text"  class="form-control" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-5">
					  <div class="radio" style="padding-top:1px;">
                          <input id="male" type="radio" name="gender" value="male" checked="checked">
                          <label for="male">Male</label>
                          <input id="female" type="radio" name="gender" value="female">
                          <label for="female">Female</label>
                        </div>
                      </div>
					  
                      <div class="col-md-7">
                        <input type="text" placeholder="Date of Birth" class="form-control" id="d_dateofbirth" name="form3DateOfBirth">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-5">
                        <input name="bloodgroup" id="d_bloodgroup" type="text"  class="form-control" placeholder="Blood Group">
                      </div>
					  <div class="col-md-7">
                        <input name="qualification" id="d_qualification" type="text"  class="form-control" placeholder="Qualification">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-12">
                        <input name="form3Email" id="d_emailaddress" type="text"  class="form-control" placeholder="email@address.com">
                      </div>
                    </div>
                </div>
                <div class="col-md-6">
                  <h4>Consultation Info</h4>
					<div class="row form-row">
                      <div class="col-md-12">
                        <input name="specialisation" id="d_specialisation" type="text"  class="form-control" placeholder="Specialisation">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-12">
                        <input name="consult_interval" id="d_consult_interval" type="text"  class="form-control" placeholder="Consultation Interval">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-6">
                        <input name="consult_fee" id="d_consult_fee" type="text"  class="form-control" placeholder="Consulting Fee">
                      </div>
                      <div class="col-md-6">
                        <input name="consult_renew_fee" id="d_consult_renew_fee" type="text"  class="form-control" placeholder="Consultation Renew Fee">
                      </div>
                    </div>
                    <div class="row form-row">
					  <div class="col-md-3">
						<label>Type</label>
					  </div>
                      <div class="col-md-9">
                        <div class="radio">
                          <input id="permanent" type="radio" name="type" value="permanent">
                          <label for="permanent">Permanent</label>
                          <input id="visiting" type="radio" name="type" value="visiting" checked="checked">
                          <label for="visiting">Visiting</label>
                        </div>
                      </div>
                    </div>
                     <div class="row form-row">
					 <div class="col-md-3">
						<label>Status</label>
						</div>
                      <div class="col-md-9">
                        <div class="radio">
                          <input id="status1" type="radio" name="status" value="yes" checked="checked">
                          <label for="yes">Yes</label>
                          <input id="status2" type="radio" name="status" value="no">
                          <label for="no">No</label>
                        </div>
                      </div>
                    </div>
                </div>
				
              </div>
                      </div>
                      <div class="tab-pane" id="tab2"> <br>
						<div class="row column-seperation">                
						<div class="col-md-9">
						  <h4>Postal Info</h4>
							<div class="row form-row">
							  <div class="col-md-12">
								<input name="form3Address" id="d_postalinfo" type="text"  class="form-control" placeholder="Address">
							  </div>
							</div>
							<div class="row form-row">
							  <div class="col-md-6">
								<input name="form3City" id="d_city" type="text"  class="form-control" placeholder="City">
							  </div>
							  <div class="col-md-6">
								<input name="form3State" id="d_state" type="text"  class="form-control" placeholder="State">
							  </div>
							</div>
							<div class="row form-row">
							  <div class="col-md-8">
								<input name="form3Country" id="d_country" type="text"  class="form-control" placeholder="Country">
							  </div>
							  <div class="col-md-4">
								<input name="form3PostalCode" id="d_postalcode" type="text"  class="form-control" placeholder="Postal Code">
							  </div>
							</div>
							<div class="row form-row">
							  <div class="col-md-4">
								<input name="form3TeleCode" id="form3TeleCode" type="text"  class="form-control" placeholder="+91">
							  </div>
							  <div class="col-md-8">
								<input name="form3TeleNo" id="d_mobileno" type="text"  class="form-control" placeholder="Phone Number" maxlength="10" onkeypress="return charonly(event)" onblur="mobilevalid();">
							  </div>
							</div>
						</div>
						<div class="col-md-3">
						  <h4>Doctor Photo</h4>            
							<img src="../assets/img/profiles/placeholder.jpg" id="sampleimg" style="width:100%;">
							<img src="" id="img" style="width:100%;display:none;">
							<input type="file" name="photoimg" id="photoimg" style="width:100%;">
						</div>
						
					  </div>
                        
                      </div>
                      <!--<div class="tab-pane" id="tab3"> <br>
                        <h4 class="semi-bold">Step 3 - <span class="light">User Settings</span></h4>
                        <br>
                      </div>
                      <div class="tab-pane" id="tab4"> <br>
                        <h4 class="semi-bold">Step 4 - <span class="light">Feedback</span></h4>
                        <br>
                      </div>-->
                      <ul class=" wizard wizard-actions" style="text-align: right;">
                        <li class="previous first" style="display:none;"><a href="javascript:;" class="btn">&nbsp;&nbsp;First&nbsp;&nbsp;</a></li>
                        <li class="previous"><a href="javascript:;" class="btn">&nbsp;&nbsp;Previous&nbsp;&nbsp;</a></li>
                        <li class="next last" style="display:none;"><a href="javascript:;" class="btn btn-primary">&nbsp;&nbsp;Last&nbsp;&nbsp;</a></li>
                        <li class="next"><a href="javascript:;" id='nextbutton' class="btn btn-primary">&nbsp;&nbsp;Next&nbsp;&nbsp;</a></li>
                      </ul>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
  
      </div>
    </div>
  </div>
</div>
<!-- END PAGE -->
<!-- END CONTAINER -->
<!-- BEGIN CORE JS FRAMEWORK-->
<script src="../assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="../assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/plugins/breakpoints.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
<!-- END CORE JS FRAMEWORK -->
<!-- BEGIN PAGE LEVEL JS -->
<script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script> 
<script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="../assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
<script src="../assets/plugins/boostrap-form-wizard/js/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!--<script src="../assets/js/form_validations.js" type="text/javascript"></script>-->
<script type="text/javascript" src="../assets/js/doctor/doctor.js"></script>
<!-- BEGIN CORE TEMPLATE JS -->
<script src="../assets/js/core.js" type="text/javascript"></script>
<script src="../assets/js/demo.js" type="text/javascript"></script>
<!-- END CORE TEMPLATE JS -->
<!-- END JAVASCRIPTS -->
</body>
</html>