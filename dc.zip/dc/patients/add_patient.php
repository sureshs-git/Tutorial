<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Patient Registration</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />
<script src="../assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<link href="../assets/plugins/jquery-notifications/css/messenger.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="../assets/plugins/jquery-notifications/css/messenger-theme-flat.css" rel="stylesheet" type="text/css" media="screen"/>
<!-- BELOW CSS FILE IS NOT REQUIRED -->
<link href="../assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
<?php include '../templates/header_includes.php'; ?>
</head>
<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN HEADER -->
<?php include '../templates/header.php'; ?>
<!-- END HEADER --> 
<!-- BEGIN CONTAINER -->
<div class="page-container row"> 
  <!-- BEGIN SIDEBAR -->
  <?php include '../templates/sidebar.php'; ?>
  <a href="#" class="scrollup">Scroll</a>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
	 <div class="page-content">
		<div class="clearfix"></div>
		<div class="content">
			<div class="col-md-5">
				<ul class="breadcrumb">
					<li><p>Patients</p></li>
					<li><a href="#" class="active">Patient Registration</a> </li>
				</ul>
			</div>
			<div class="page-title col-md-7"> 
				<h3> <span class="semi-bold">Patient Registration</span></h3>
			</div>  
			<div class="row">
				<div class="col-md-12">
					<ul class="nav nav-pills" id="tab-01">
						<li class="active" style="width:39%;margin-left:10%;"><a href="#mandatorydetails">BASIC PROFILE</a></li>
						<li class="" style="width:39%;margin-right:10%;margin-left:0px;padding-left:1px;  border-radius: 3px;"><a href="#advanceddetails">ADVANCED PROFILE</a></li>
					</ul>
					<div class="tools"> 
						<a href="javascript:;" class="collapse"></a> <a href="#grid-config" data-toggle="modal" class="config"></a> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> 
					</div>
					<div class="tab-content" style="border:3px solid;">
						<div class="tab-pane active" id="mandatorydetails">
							<div class="row column-seperation">
								<div class="grid-body" style="padding: 0 10px;">
									<form id="p_basic_profile" name="patient_register" action="" method="post">	
										<div class="row column-seperation">
											<div class="col-md-5">
											  <!--<h4>Basic Information</h4> --> <div style="height:20px;">          </div>
												<div class="row form-row">
													<?php 
													$sql = "SELECT p_uid_prefix FROM admin";
													$uid_pre = $conn->query($sql);
													if($uid_pre){
														while($row1 = $uid_pre->fetch_assoc()) {
															$uid_prefix=$row1['p_uid_prefix'];
														}
													}
													$sql = "SELECT p_uid FROM patient_details ORDER BY patient_id DESC LIMIT 1";
													$result = $conn->query($sql);
													if (mysqli_num_rows($result) > 0) {
														while($row = $result->fetch_assoc()) {
															$uid=$row['p_uid'];								
														}
													}
													else{
														$uid='AMDS/IQDS/001';	
													}
													?>
													<div class="col-md-12">
														<span class="uidspan1">UID</span>
														<span class="uidspan2 tip" data-original-title="Auto Generated ID" title data-placement="right"><?php echo $uid_prefix;echo $uid+1; ?></span>
														<input type="hidden" name="p_uid" id="p_uid" value="<?php echo $uid+1 ; ?>">
													</div>
												</div><br>
												<div class="row form-row">
													<div class="col-md-4">
														<select name="p_title" id="p_title" class="dropdown100">
															<option value="">Select Title</option>
															<option value="Baby.">Baby</option>
															<option value="Dr.">Dr.</option>
															<option value="Master.">Master.</option>
															<option value="Miss.">Miss.</option>
															<option value="Mr.">Mr.</option>
															<option value="Mrs.">Mrs.</option>
															<option value="Ms.">Ms</option>
															<option value="Prof.">Prof.</option>
														</select>
													</div>
													<div class="col-md-8">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<input name="p_fname" id="p_fname" type="text" class="form-control" placeholder="First Name">
														</div>	
													</div>
												</div>
												<div class="row form-row">
													<div class="col-md-6">
														<input name="p_mname" id="p_mname" type="text"  class="form-control" placeholder="Middle Name">
													</div>
													<div class="col-md-6">
														<input name="p_lname" id="p_lname" type="text"  class="form-control" placeholder="Last Name">
													</div>
												</div>
												<div class="row form-row">
													<div class="col-md-4">
													    <select name="p_gender" id="p_gender" class="dropdown100">
															<option value="">Select Gender</option>
															<option value="Male">Male</option>
															<option value="Female">Female</option>
															<option value="Trans">Trans</option>
													    </select>
													</div>
													<div class="col-md-8">
														<div class="input-append success date">
														  <input type="text" class="form-control" value='' id="p_dob" name="p_dob" placeholder="DOB" style="width:109%;" readonly>
														  <span class="add-on"><span class="arrow"></span><i class="fa fa-th"></i></span>
														</div>
													</div> 			
												</div>
												<div class="row form-row">
													<div class="col-md-4">
														<input name="p_ccode" id="p_ccode" type="text"  class="form-control" placeholder="+91" maxlength="3">
													</div>
													<div class="col-md-8">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<input name="p_phone" id="p_phone" type="text" value='' class="form-control" placeholder="Mobile Number" maxlength="10" onkeypress="return charonly(event)" onblur="mobilevalid10();">
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-5">				
											  <!--<h4>Postal Information</h4>    --> <div style="height:20px;"> </div>
											    <div class="row form-row">
													<div class="col-md-12">
														<span class="uidspan1">OLD ID</span>
														<span class="uidspan2 tip" data-original-title="Patient's Old ID" title data-placement="right">XY005678</span>
														
													</div>
												</div>	<br>
												<div class="row form-row">
													<div class="col-md-12">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<input name="p_address" id="p_address" type="text"  class="form-control" placeholder="Address">
														</div>
													</div>
												</div>
												<div class="row form-row">
													<div class="col-md-6">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<input name="p_city" id="p_city" type="text"  class="form-control" placeholder="City">
														</div>
													</div>
													<div class="col-md-6">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<select class="dropdown100" name="country_id" id="country_id" onChange="getstate(this.value);" required>
																<option value="">Select Country</option>
																<?php 
																$sql_query1 = mysqli_query($conn,"SELECT * FROM country"); 
																while($row = mysqli_fetch_array($sql_query1)){ ?>
																   <option value = "<?php echo $row["country_id"]; ?>"> <?php echo $row["country"]; ?></option>
															   <?php }  ?>									
															</select>
														</div>
													</div>
												</div>
												<div class="row form-row">
													<div class="col-md-8">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<select name="state_id" id="state_id"  class="dropdown100">
																<option value="">Select State</option>
															</select>
														</div>
													</div>
													<div class="col-md-4">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<input name="p_postalcode" id="p_postalcode" type="text"  class="form-control" placeholder="Postal Code" maxlength="6" onkeypress="return charonly(event)" onblur="zipvalid6();">
														</div>
													</div>
												</div>
												<div class="row form-row">
													<div class="col-md-12">
														<div class="input-with-icon right">                                       
															<i class=""></i>
															<input type="text" name="form1Email" id="p_email" class="form-control" placeholder="email@address.com" onChange="getemail(this.value);">  
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-2">
											  <h4>Patient Photo</h4> 
												<div class='photo_error' style='display:none;color:red;'> </div>
												<div id="preview">
													<img src="../assets/img/profiles/placeholder.jpg" id="sampleimg" style="width:100%;">
													<img src="" id="img" style="width:100%;display:none;">
												</div>
													<!--<form class="cd-form1 no-pad" id="imageform" name="imageform" method="post" action="functions.php" 
													target="_top" enctype="multipart/form-data">-->
													<input type="file" name="photoimg" id="photoimg" style="width:100%;">
													<button>Take Snap</button>
													<!--</form>-->
											</div>
										</div>
										<div class="col-md-10">
											<div id="confirmation"></div>
												<input type="hidden" name="add_patient_man" id="add_patient_man" value="add_patient_man">
											<div class="form-actions"> 
												<div class="" style="text-align: center;">
													<button class="btn btn-white btn-cons tip" type="button" onClick="window.location.reload()" data-original-title="Click to reset data !"><i class="fa fa-refresh"></i> Reset</button>
													<a class="btn btn-primary btn-cons tip" id="add_new_patient" onClick="window.location.reload()" data-original-title="Click to AddNew Patient !"><i class="fa fa-check"></i> Save</a>
													<button class="btn btn-success btn-cons tip" type="submit" id="p_mandatory_info" data-original-title="Click to save !"> Save & Continue <i class="fa fa-arrow-circle-right"></i></button>
												</div>
											</div>
										</div>
										<div class="col-md-2">
										<div id="qrcode"></div>
										</div>
									</form>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="advanceddetails">
							<div class="row">
								<div class="grid-body" style="padding: 0 10px;">
									<form id="p_advance_profile" action="" method="post">	
									  <div class="row column-seperation">
										<div class="col-md-6">
										   <div style="height:20px;">          </div> 
										   <div class="row form-row">
												<div class="col-md-5">
													<div class="input-with-icon right">
														<select class="dropdown100" name="uid_advance" id="uid_advance" onChange="getname(this.value);" required>
															<option value="">Select UID</option>
															<?php 
															$sql = "SELECT p_uid_prefix FROM admin";
															$uid_pre = $conn->query($sql);
															if($uid_pre){
																while($row1 = $uid_pre->fetch_assoc()) {
																	$uid_prefix=$row1['p_uid_prefix'];
																}
															}
															$sql_query1 = mysqli_query($conn,"SELECT * FROM patient_details"); 
															while($row = mysqli_fetch_array($sql_query1)){ ?>
															   <option value = "<?php echo $row["p_uid"]; ?>"> <?php echo $row["p_uid"]; ?></option>
															  
														   <?php }  ?>									
														</select>
													</div>
												</div>	
												<div id="p_name_adv" class="col-md-7">
													
												</div>
											</div>       
											<div class="row form-row">
												<div class="col-md-5">
													<select name="p_bloodgrp" id="p_bloodgrp" class="dropdown100">
														<option value="">Select Blood Group</option>
														<option value="A+ve">A+ve</option>
														<option value="A-ve">A-ve</option>
														<option value="B+ve">B+ve</option>
														<option value="B-ve">B-ve</option>
														<option value="O+ve">O+ve</option>
														<option value="O-ve">O-ve</option>
														<option value="AB+ve">AB+ve</option>
														<option value="AB-ve">AB-ve</option>
													</select>
												</div>
												<div class="col-md-7">
													<input name="p_occupation" id="p_occupation" type="text"  class="form-control" placeholder="Occupation">
												</div>
											</div>
											<div class="row form-row">
												<div class="col-md-5">
													<select name="p_marrystatus" id="p_marrystatus" class="dropdown100">
														<option value="">Select Marital Status</option>
														<option value="Single">Single</option>
														<option value="Married">Married</option>
														<option value="Widower">Widower</option>
														<option value="Divorcee">Divorcee</option>
													</select>
												</div>
												<div class="col-md-7">
													 <input name="p_religion" id="p_religion" type="text"  class="form-control" placeholder="Religion">
												</div> 			
											</div>
											<div class="row form-row">
												<div class="col-md-12">
												  <textarea id="p_workaddr" placeholder="Enter Patient's Work Address ..." class="form-control" rows="3"></textarea>
												</div>
											</div>
											<div class="row form-row">
												<div class="col-md-5">
													<label>First Time Visitor</label>
													<div class="radio">
													  <input id="first_visit1" type="radio" name="first_visit" value="Yes" checked="checked">
													  <label for="first_visit1">Yes</label>
													  <input id="first_visit2" type="radio" name="first_visit" value="No">
													  <label for="first_visit2">No</label>
													</div>
												</div>
												<div class="col-md-7">
													<select name="p_referredby" id="p_referredby" class="dropdown100">
														<option value="">Referred By</option>
													</select>
												</div>
											</div>
										</div>
										<div class="col-md-6">				
										  <div style="height:20px;"></div>
											<div class="row form-row">
												<div class="col-md-12">
													<input name="p_insure_no" id="p_insure_no" type="text"  class="form-control" placeholder="Insurance Number">
												</div>
											</div>
											<div class="row form-row">
												<div class="col-md-6">
													<input name="p_spousename" id="p_spousename" type="text"  class="form-control" placeholder="Spouse Name">
												</div>
												<div class="col-md-6">
													<input name="p_fax" id="p_fax" type="text"  class="form-control" placeholder="Fax">
												</div>
											</div>
											<div class="row form-row">
												<div class="col-md-6">
													<input name="p_guardname" id="p_guardname" type="text"  class="form-control" placeholder="Guardian Name">
												</div>
												<div class="col-md-6">
													<input name="p_guardnum" id="p_guardnum" type="text"  class="form-control" placeholder="Guardian Mobile">
												</div>
											</div>
											<div class="row form-row">
												<div class="col-md-12">
													<textarea id="p_remarks" placeholder="Enter Remarks here..." class="form-control" rows="3"></textarea>
												</div>
											</div>
											<div class="row form-row">
												<div class="col-md-12">
													<textarea id="p_spcl_ins" placeholder="Special Instructions here..." class="form-control" rows="3"></textarea>
												</div>
											</div>
										</div>
										</div>
										<div id="confirmation"></div>
										<input type="hidden" name="add_advance_patient_man" id="add_advance_patient_man" value="add_advance_patient_man">
										<div class="form-actions" style="margin-top:0px;margin-bottom:0px;"> 
											<div class="" style="text-align: center;">
												<button class="btn btn-success btn-cons tip" type="submit" id="p_advance_info" data-original-title="Click to save !"><i class="fa fa-check"></i> Submit</button>
												<button class="btn btn-white btn-cons tip" type="button" id="reset_adv" data-original-title="Click to reset !"><i class="fa fa-refresh"></i>&nbsp;&nbsp;Reset</button>
												  <!--<button class="btn btn-danger btn-cons" >Show Error Messsage</button>-->
												<input type="hidden" id="add_patient_advance" value="add_patient_advance">
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
  </div>
</div>
<!-- END PAGE -->
<!-- END CONTAINER -->
<?php include '../templates/footer_includes.php'; ?>

<!--<script type="text/javascript" src="../assets/js/patients/validation.js"></script>-->
<script type="text/javascript" src="../assets/js/patients/qrcode_generate.js"></script>
<script type="text/javascript" src="../assets/js/patients/functions.js"></script>
<link href="../assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
<!--<script src="../assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>-->

<script type="text/javascript">
//$(document).ready(function(){ 
	// $("#cancel").click(function () {
		// $('#P_details_advanced')[0].reset();
	 // });
	// });
	/*$(document).ready(function() 
	 { 
	 
	 $.noConflict();
	$("#photoimg").live('change', function () {
		 //Get count of selected files
		 var countFiles = $(this)[0].files.length;

		 var imgPath = $(this)[0].value;
		 var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
		 var image_holder = $("#preview");
		 image_holder.empty();

		 if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
			 if (typeof (FileReader) != "undefined") {

				 //loop for each file selected for uploaded.
				 for (var i = 0; i < countFiles; i++) {

					 var reader = new FileReader();
					 reader.onload = function (e) {
						 $("<img />", {
							 "src": e.target.result,
								 "class": "preview"
						 }).appendTo(image_holder);
					 }

					 image_holder.show();
					 reader.readAsDataURL($(this)[0].files[i]);
				 }

			 } else {
				 alert("This browser does not support FileReader.");
			 }
		 } else {
			 alert("Pls select only images");
		 }
	 });
	  }); */
</script>

</body>
</html>
