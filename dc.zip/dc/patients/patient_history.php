<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Patient History</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<?php include '../templates/header_includes.php'; ?>
</head>
<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN HEADER -->
<?php include '../templates/header.php'; ?>
<!-- END HEADER --> 
<!-- BEGIN CONTAINER -->
<div class="page-container row"> 
  <!-- BEGIN SIDEBAR -->
  <?php include '../templates/sidebar.php'; ?>
  <a href="#" class="scrollup">Scroll</a>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    
    <div class="clearfix"></div>
    <div class="content">
        <div class="col-md-5">
			<ul class="breadcrumb">
				<li><p>Patients</p></li>
				<li><a href="#" class="active">Patient History</a> </li>
			</ul>
		</div>
		<div class="page-title col-md-7"> 
			<h3> <span class="semi-bold">Patient History</span></h3>
		</div> 
      <div class="row">
        <div class="col-md-12">
          <div class="grid simple">
            <div class="grid-title no-border">
			<h4> <span class="semi-bold">Patients List</span></h4>
              <div class="tools"> <a href="javascript:;" class="collapse"></a><!-- <a href="#grid-config" data-toggle="modal" class="config"></a> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a>--> </div>
            </div>
            <div class="grid-body">
			
          <div class="tabbable tabs-right">
            <ul class="nav nav-tabs" id="tab-3">
			<li class=""><a href="#tab3hellowWorld" class="tip" data-original-title="Click to go all in one !">All in One</a></li>
              <li class=""><a href="#tab3hellowWorld">Prescription</a></li>
              <li><a href="#tab3FollowUs">Prescription Bill</a></li>
              <li class="active"><a href="#tab3Inspire">Patient History</a></li>
			  <li class=""><a href="#tab3hellowWorld">Clinical Examination</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane " id="tab3hellowWorld" style="padding-top:0;">
                <div class="row column-seperation">
                  <div class="row-fluid">
        <div class="span12">
          <div class="grid simple ">
            <div class="grid-body ">
              <table class="table" id="example3" >
                <thead>
                  <tr>
					<th>S. No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Occupation</th>
                    <th>Email</th>
                    <th>Phone Number</th>
					<th>Country</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="odd gradeX">
                    <td>1</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>2</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>3</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
                  <tr class="odd gradeX">
                    <td>4</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>5</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>6</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>7</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>8</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>9</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>10</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>11</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>12</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>13</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>14</td>
                    <td>Thana</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
                </div>
              </div>
              <div class="tab-pane" id="tab3FollowUs" style="padding-top:0;padding-left:0;">
                <div class="row">
                  <div class="col-md-12">
                    <div class="row-fluid">
        <div class="span12">
          <div class="grid simple ">
            
            <div class="grid-body ">
              <table class="table" id="example3" >
                <thead>
                  <tr>
					<th>S. No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Occupation</th>
                    <th>Email</th>
                    <th>Phone Number</th>
					<th>Country</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="odd gradeX">
                    <td>1</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>2</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>3</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
                  <tr class="odd gradeX">
                    <td>4</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>5</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>6</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>7</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>8</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>9</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>10</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>11</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>12</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>13</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>14</td>
                    <td>Thana</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane active" id="tab3Inspire" style="padding-top:0;padding-left:0;">
                <div class="row">
                  <div class="col-md-12">
                    <div class="row-fluid">
        <div class="span12">
          <div class="grid simple ">
            
            <div class="grid-body ">
              <table class="table" id="example3" >
                <thead>
                  <tr>
					<th>S. No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Occupation</th>
                    <th>Email</th>
                    <th>Phone Number</th>
					<th>Country</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="odd gradeX">
                    <td>1</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>2</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>3</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
                  <tr class="odd gradeX">
                    <td>4</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>5</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>6</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>7</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>8</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>9</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>10</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>11</td>
                    <td>Thangavel</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  <tr class="odd gradeA">
                    <td>12</td>
                    <td>Kannan</td>
                    <td>Selvan</td>
                    <td class="center"> Carpenter</td>
                    <td class="center">kanna@yahoo.com</td>
					<td>923498777</td>
					<td>USA</td>
                  </tr>
				  <tr class="odd gradeX">
                    <td>13</td>
                    <td>Ragu</td>
                    <td>Ram</td>
                    <td class="center"> Engineer</td>
                    <td class="center">ragura@gmail.com</td>
					<td>987654321</td>
					<td>Thailand</td>
                  </tr>
                  <tr class="even gradeC">
                    <td>14</td>
                    <td>Thana</td>
                    <td>Raj</td>
                    <td class="center"> Manager</td>
                    <td class="center">thangaraj@ymail.com</td>
					<td>98763490</td>
					<td>India</td>
                  </tr>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        
            </div>
			
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END PAGE -->
<!-- END CONTAINER -->

<script src="assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="assets/js/tabs_accordian.js" type="text/javascript"></script>
<?php include '../templates/footer_includes.php'; ?>

</body>
</html>