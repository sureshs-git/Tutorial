<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Patients - All in one</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<!-- BEGIN CORE CSS FRAMEWORK -->
<link href="../assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<!-- END CORE CSS FRAMEWORK -->

<!-- BEGIN CSS TEMPLATE -->
<link href="../assets/css/themes/simple/style.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/themes/simple/responsive.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/design-style.css" rel="stylesheet" type="text/css"/>
<!-- END CSS TEMPLATE -->
</head>
<!-- END HEAD -->

<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN HEADER -->
<?php include '../templates/header.php'; ?>
<!-- END HEADER -->
<!-- BEGIN CONTAINER -->
<div class="page-container row-fluid">
  <!-- BEGIN SIDEBAR -->
  <?php include '../templates/sidebar.php'; ?>
    <!-- END SIDEBAR MENU --> 
  </div>
  </div>
  <a href="#" class="scrollup">Scroll</a>
   <div class="footer-widget">		
	<div class="progress transparent progress-small no-radius no-margin">
		<div data-percentage="79%" class="progress-bar progress-bar-success animate-progress-bar" ></div>		
	</div>
	<div class="pull-right">
		<div class="details-status">
		<span data-animation-duration="560" data-value="86" class="animate-number"></span>%
	</div>	
	<a href="lockscreen.html"><i class="fa fa-power-off"></i></a></div>
  </div>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">   
    <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
    <div id="portlet-config" class="modal hide">
      <div class="modal-header">
        <button data-dismiss="modal" class="close" type="button"></button>
        <h3>Widget Settings</h3>
      </div>
      <div class="modal-body"> Widget settings form goes here </div>
    </div>
    <div class="clearfix"></div>
    <div class="content"> 
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding tot_side">
		<div class="col-lg-2 col-mg-2 col-sm-2 col-xs-12 left_side">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding show_malar">
				<h4 class="title_h4">Show 3rd Molar</h4>
				<form>
					<label class="radio-inline"><input type="radio" name="optradio">Yes</label>
					<label class="radio-inline"><input type="radio" name="optradio">No</label>
				</form>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding date_time">
				<div class="form-group clearfix">
					<label class="col-md-3 no_padding">Date</label>
					<!-- <div class="input-append success date col-md-9 no_padding">
						<input id="sandbox-advance" type="text" name="date" class="form-control">
						<span class="add-on"><span class="arrow"></span><i class="fa fa-th"></i></span>
					</div> -->
					<div class="input-append success date col-md-9 no_padding col-lg-6">
                      <input type="text" class="form-control" id="sandbox-advance">
                      <span class="add-on"><span class="arrow"></span><i class="fa fa-th"></i></span>
					</div> 
				</div>
				<div class="form-group clearfix">
					<label class="col-md-3 no_padding">Time</label>
					<div class="col-md-9 no_padding">
						<input type="number" name="date" class="form-control">
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding tooth_num">
				<h4 class="title_h4">Tooth Numbering</h4>
				<form>
					<label class="radio-inline"><input type="radio" name="optradio">ADA</label>
					<label class="radio-inline"><input type="radio" name="optradio">UK</label>
				</form>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding list_items">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
					<h5 class="qu_entry">Quick Entry</h5>
					<form>
					<label class="radio-inline"><input type="radio" name="optradio">New Bill</label>
					<label class="radio-inline"><input type="radio" name="optradio">All</label>	
					</form>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
					<ul class="list_items1">
						<li><a href="javascript: void(0);">Payment Report</a>
							<span><i class="fa fa-book"></i></span>	
						</li>
						<li><a href="javascript: void(0);">View</a>
							<span><i class="fa fa-eye"></i></span>							
						</li>
						<li><a href="javascript: void(0);">Payment History</a>
							<span><i class="fa fa-road"></i></span>
						</li>
						<li><a href="javascript: void(0);">set as visited</a>
							<span><i class="fa fa-sort-amount-asc"></i></span>
						</li>
						<li><a href="javascript: void(0);">set as visited</a>
							<span><i class="fa fa-picture-o"></i></span>
						</li>
						<li><a href="javascript: void(0);">Recall</a>
							<span><i class="fa fa-sitemap"></i></span>
						</li>
						<li><a href="javascript: void(0);">Prescription</a>
							<span><i class="fa fa-inbox"></i></span>
						</li>
						<li><a href="javascript: void(0);">Note</a>
							<span><i class="fa fa-hdd-o"></i></span>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="col-lg-8 col-mg-8 col-sm-8 col-xs-12 center_div">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
				<h1 class="page_title">DIAGNOSIS/TREATMENT</h1>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
				<ul class="toot_list">
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal" >
							<img src="assets/img/tot.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal">
							<img src="assets/img/tot1.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal">
							<img src="assets/img/tot2.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal">
							<img src="assets/img/tot3.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal">
							<img src="assets/img/tot2.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal">
							<img src="assets/img/tot1.png" class="img-responsive" />							 
						</a>
					</li>
				</ul>
			</div>		
			<div class="check_div col-lg-8 col-mg-8 col-sm-8 col-xs-12">							
					<label class="checkbox-inline">
						<div class="checkbox check-default ">
							<input id="checkbox1" type="checkbox" value="1" class="checkall">
							<label for="checkbox1">Select All Tooth</label>
							</div>
					</label>
					<label class="checkbox-inline">
						<div class="checkbox check-default ">
							<input id="checkbox2" type="checkbox" value="1" class="checkall">
							<label for="checkbox2">Decidous Tooth</label>
							</div>
					</label>
			</div>			 		
		</div>
		<div class="col-lg-2 col-mg-2 col-sm-2 col-xs-12 right_side">
			<div align="center" class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding prf_img">
				<img src="assets/img/profiles/avatar.jpg" class="img-responsive img-rounded" />
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding pai_det">
				<h4 class="title_h4">New Paitent</h4>
				<ul class="pari_details">
					<li>Abdul kharthar</li>
					<li>Balance: 500</li>
					<li>Doctor Name</li>
					<li>XXXXX</li>
				</ul>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
				<h3 class="apoi_tit">Appointment List</h3>
				<div class="table-responsive">
					<table class="apoi_table">
						<tr>
							<th>name</th>
							<th>age</th>
							<th>time</th>
							<th>Date</th>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
					</table>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
				<a href="javascript: void(0);" data-toggle="modal" data-target="#new_apoint" class="btn btn_new_apo">New Appointment</a>
				<a href="javascript: void(0);" data-toggle="modal" data-target="#apoint_list" class="btn btn_to_apo">Today Appointment List</a>
			</div>
		</div>
	</div>    	 
    </div>
  </div> 
</div>
 
 
<!-- END CONTAINER --> 
<!-- BEGIN CORE JS FRAMEWORK--> 
<script src="../assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script> 
<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script> 
<script src="../assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script> 
<script src="../assets/plugins/breakpoints.js" type="text/javascript"></script> 
<script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script> 
<script src="../assets/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script> 
<!-- END CORE JS FRAMEWORK --> 
<!-- BEGIN PAGE LEVEL JS --> 	
<script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>  
<script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS --> 	

<!-- BEGIN CORE TEMPLATE JS --> 
<script src="../assets/js/core.js" type="text/javascript"></script> 
<script src="../assets/js/chat.js" type="text/javascript"></script> 
<script src="../assets/js/demo.js" type="text/javascript"></script> 
<!-- END CORE TEMPLATE JS -->


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg list_out_model">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Full Decsriptions</h4>
        </div>
        <div class="modal-body full_des">
           <ul class="nav nav-tabs">
			<li class="active"><a data-toggle="tab" href="#home">Chief Complients</a></li>
			<li><a data-toggle="tab" href="#menu1">Diagnosis</a></li>
			<li><a data-toggle="tab" href="#menu2">Treatment</a></li>
			<li><a data-toggle="tab" href="#menu3">Prescription</a></li>
			<li><a data-toggle="tab" href="#menu4">Detail(s)</a></li>
		  </ul>
		  <div class="tab-content">
			<div id="home" class="tab-pane fade in active">
				<ul class="toot_list">
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal" >
							<img src="assets/img/tot.png" class="img-responsive" />							 
						</a>
					</li>
				</ul>
				<div class="col-md-12 col-sm-12 col-xs-12 col-md-12 no_padding">
					<div class="col-md-6 col-sm-6 col-xs-12 col-md-6">
						 <div class="table-responsive">
							<table class="table chef_complients_table">
								<tr>
									<th>Date</th>
									<th>Chief Complients</th>
									<th>Action</th>									 
								</tr>
								<tr>
									<td>06-10-2015</td>
									<td>Not working properly</td>
									<td align="center"><img src="assets/img/del_icon.png" class="img-responsive" /></td>
								</tr>
							</table>
						</div>
					</div>
					<div class="col-md-6 col-sm-6 col-xs-12 col-md-6">
						<form class="form-horizontal">
							<div class="form-group">
								<textarea cols="43" rows="4">
								</textarea>
							</div>
							<div class="form-group">
								<button type="button" class="btn btn-primary btn_save">Save</button>
								
								<button type="button" class="btn btn-primary btn_canl">Cancel</button>								
							</div>
						</form>
					</div>
				</div>			   
			</div>
			<div id="menu1" class="tab-pane fade">
				<ul class="toot_list">
					<li>
						<a href="javascript: void(0);" data-toggle="modal" data-target="#myModal" >
							<img src="assets/img/tot.png" class="img-responsive" />							 
						</a>
					</li>
				</ul>
				<div align="right" class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
					<a href="javascript: ">
						<img src="assets/img/add_icon.png" class="img-responsive" />	
					</a>
				</div>
			  <div class="table-responsive">
					<table class="table dis_table">
						<tr>
							<th>Sl</th>
							<th>Date & Time</th>
							<th>Diagnosis</th>
							<th>Tooth</th>
							<th>Dr.Name</th>
							<th>Status</th>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2015</td>
							<td>Middle</td>
							<td>25-06-2015</td>
							<td>sankar</td>
							<td align="center">
								<ul class="status_btns">
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
								</ul>							
									
							</td>
						</tr>
						 
						<tr>
							<td>1</td>
							<td>25-06-2015</td>
							<td>Middle</td>
							<td>25-06-2015</td>
							<td>sankar</td>
							<td align="center">
								<ul class="status_btns">
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
								</ul>							
									
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2015</td>
							<td>Middle</td>
							<td>25-06-2015</td>
							<td>sankar</td>
							<td align="center">
								<ul class="status_btns">
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
								</ul>							
									
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2015</td>
							<td>Middle</td>
							<td>25-06-2015</td>
							<td>sankar</td>
							<td align="center">
								<ul class="status_btns">
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
								</ul>							
									
							</td>
						</tr>
					</table>
				</div>
			</div>
			<div id="menu2" class="tab-pane fade">
				<ul class="toot_list">
					<li>
						<a href="javascript: void(0);"  >
							<img src="assets/img/tot.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);"  >
							<img src="assets/img/tot1.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);"   >
							<img src="assets/img/tot2.png" class="img-responsive" />							 
						</a>
					</li>
					<li>
						<a href="javascript: void(0);"  >
							<img src="assets/img/tot3.png" class="img-responsive" />							 
						</a>
					</li>
				</ul>
			  <div class="table-responsive">
					<table class="table tratme_table">
						<tr>
							<th>Sl</th>
							<th>Date & Time</th>
							<th>Treatment</th>
							<th>Tooth</th>
							<th>Dr.Name</th>
							<th>Est.Amt</th>
							<th>Discount</th>
							<th>Paid</th>
							<th>Balance</th>
							<th>Mode</th>
							<th>Status</th>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
					</table>
				</div>
			</div>
			<div id="menu3" class="tab-pane fade">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12  ">
						<div class="table-responsive">
					<table class="table tratme_table">
						<tr>
							<th>#</th>
							<th>Drag</th>
							<th>Frequency</th>
							<th>Period</th>
							<th>Remarks</th>							 
							<th>Status</th>
						</tr>
						<tr>
							<td>1</td>							 
							<td>Tooth</td>
							<td>Tooth</td>							 
							<td>250</td>
							<td>50</td>							 
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>2</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>250</td>
							<td>250</td>
						 	 							 
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>50</td>
							 
							 
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							 
							 
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
					</table>
				</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pre_bor">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
							<form class="form-horizontal pres_form">
								<div class="form-group">
									<h5 class="form_title">Prescription Date : <span> 14-Jun -2016 </span></h5>
								</div>
								<div class="form-group">
									<div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
										<p class="pre_des">New Prescription</p>
									</div>
									<div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
										<select class="form-control">
											<option></option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<div class="col-lg-4 col-md-4 col-xs-12 col-sm-8">
										<p>Drug</p>
									</div>
									<div class="col-lg-8 col-md-8 col-xs-12 col-sm-8">
										<select class="form-control">
											<option></option>
										</select>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-lg-6 col-md-6 col-xs-12 col-sm-6 no_padding">
										<p>Drug</p>
									</label>
									<div class="col-lg-6 col-md-6 col-xs-12 col-sm-6 no_padding">
										<select class="form-control">
											<option></option>
										</select>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-lg-4 col-md-4 col-xs-12 col-sm-8 ">
										Duration
									</label>
									<div class="col-lg-8 col-md-8 col-xs-12 col-sm-8">
										 <input type="text" class="form-control" />
									</div>
								</div>
								
								<div class="form-group">
									<div class="col-lg-4 col-md-4 col-xs-12 col-sm-8">
										<p>Remarks</p>
									</div>
									<div class="col-lg-8 col-md-8 col-xs-12 col-sm-8">
										 <textarea cols="14" rows="4">
										 </textarea>
									</div>
								</div>
								
								<div class="form-group" align="right">
									 <button type="button" class="btn btn-primary btn_save"> Save</button>
								</div>
							</form>
						</div>
						
					</div>
				</div>
			  
			</div>
			
			<div id="menu4" class="tab-pane fade">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no_padding">
				 
						<div class="table-responsive">
					<table class="table tratme_table">
						<tr>
							<th>Sl</th>
							<th>Date & Time</th>
							<th>Treatment</th>
							<th>Tooth</th>
							<th>Dr.Name</th>
							<th>Est.Amt</th>
							<th>Discount</th>
							<th>Paid</th>
							<th>Balance</th>
							<th>Mode</th>
							<th>Status</th>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
						<tr>
							<td>1</td>
							<td>25-06-2056</td>
							<td>Tooth</td>
							<td>Tooth</td>
							<td>kian</td>
							<td>250</td>
							<td>50</td>
							<td>100</td>
							<td>100</td>
							<td>check</td>
							<td><ul class="status_btns">
									<li>
										<a href="javascript: void(0);">
											<img src="assets/img/save_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/del_icon.png" class="img-responsive" />
										</a>
									</li>
									<li><a href="javascript: void(0);"> 
											<img src="assets/img/com_icon.png" class="img-responsive" />
										</a>
									</li>
									
								</ul>	
							</td>
						</tr>
					</table>
				</div>			  
			</div>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div
  
 <!-- new appointment -->
  <div class="modal fade" id="new_apoint" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="title_h4">New Appointment List</h4>
        </div>
        <div class="modal-body">
         <div class="table-responsive">
					<table class="table">
						<tr>
							<th>name</th>
							<th>age</th>
							<th>time</th>
							<th>Date</th>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
					</table>
				</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  
  <!-- appointment List-->
   <div class="modal fade" id="apoint_list" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="title_h4">Today Appointment List</h4>
        </div>
        <div class="modal-body">
          <div class="table-responsive">
					<table class="table">
						<tr>
							<th>name</th>
							<th>age</th>
							<th>time</th>
							<th>Date</th>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
						<tr>
							<td>prabu</td>
							<td>25</td>
							<td>12.55pm</td>
							<td>12/06/2013</td>
						</tr>
					</table>
				</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  
  <script>
	$(document).ready(function() {
		$("#checkbox1").click(function() {
			 if (this.checked) {
				 
				$(".toot_list li").css({"border": "1px dashed"});
			}
			else
				{
					$(".toot_list li").css({"border": "0px dashed"});
				}
		});
	});
  </script>
  <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
  <script src="../assets/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
  
  
</body>
</html>