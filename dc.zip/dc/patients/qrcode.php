<?php
require_once("../lib/qrlib/qrlib.php");
include('../db_connection/db.php');
if(!empty($_POST["country"])) {	
$country_id ="SELECT country FROM country WHERE country_id = '" . $_POST["country"] . "'";
$country=$conn->query($country_id);
$row = mysqli_fetch_assoc($country);
$con=$row['country'];

$state_id ="SELECT state FROM state WHERE state_id = '" . $_POST["state"] . "'";
$state = $conn->query($state_id);
$row = mysqli_fetch_assoc($state);
$stat=$row['state'];
}
// Path where the images will be saved
$filepath = '../assets/img/profiles/patients_qrcode/amds/iqds/'.$_POST['uid'].'.png';
// Image (logo) to be drawn
$logopath = '../assets/img/others/login.jpg';
// qr code content
$codeContents = $_POST["title"].' '.$_POST["fname"].' '.$_POST["mname"].' '.$_POST["lname"].'('.$_POST["uid"].' - '.$_POST["gender"].'), '.$_POST["address"].', '.$_POST["city"].', '.$stat.', '.$con.' - '.$_POST["postcode"].', '.$_POST["ccode"].' '.$_POST["phone"].', '.$_POST["email"];
// Create the file in the providen path
// Customize how you want
QRcode::png($codeContents,$filepath , QR_ECLEVEL_H, 2);

// Start DRAWING LOGO IN QRCODE
$QR = imagecreatefrompng($filepath);

// START TO DRAW THE IMAGE ON THE QR CODE
$logo = imagecreatefromstring(file_get_contents($logopath));

imagecolortransparent($logo , imagecolorallocatealpha($logo , 0, 0, 0, 127));
imagealphablending($logo , false);
imagesavealpha($logo , true);

$QR_width = imagesx($QR);
$QR_height = imagesy($QR);

$logo_width = imagesx($logo);
$logo_height = imagesy($logo);

// Scale logo to fit in the QR Code
$logo_qr_width = $QR_width/3;
$scale = $logo_width/$logo_qr_width;
$logo_qr_height = $logo_height/$scale;

imagecopyresampled($QR, $logo, $QR_width/3, $QR_height/3, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height);

// Save QR code again, but with logo on it
imagepng($QR,$filepath);

// End DRAWING LOGO IN QR CODE

// Ouput image in the browser
echo '<img style="border: 3px solid #59ec0e;    border-radius: 3px;    text-align: center;;"src="'.$filepath.'" />';
//echo '<img src="myimage.png" />';  
?>