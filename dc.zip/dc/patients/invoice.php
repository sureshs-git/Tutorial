<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Patient History</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<?php include 'templates/header_includes.php'; ?>
</head>
<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN HEADER -->
<?php include 'templates/header.php'; ?>
<!-- END HEADER --> 
<!-- BEGIN CONTAINER -->
<div class="page-container row"> 
  <!-- BEGIN SIDEBAR -->
  <?php include 'templates/sidebar.php'; ?>
  <a href="#" class="scrollup">Scroll</a>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    
    <div class="clearfix"></div>
    <div class="content">
      <ul class="breadcrumb">
        <li>
          <p>Patient</p>
        </li>
        <li><a href="#" class="active">Prescription Invoice</a> </li>
      </ul>
      <div class="page-title"> <i class="fa fa-stethoscope"></i>
        <h3>Patient <span class="semi-bold">Invoice</span></h3>
      </div>  
      
       <div class="row">
      <div class="col-md-11">
        <div class="grid simple">
          <div class="grid-body no-border invoice-body"> <br>
            <div class="pull-left"> <img src="assets/img/profiles/logo.png" data-src="assets/img/profiles/logo.png" data-src-retina="assets/img/profiles/logo.png" width="" height="50" class="invoice-logo" alt=""><span style="font-weight:bold;font-size:22px;">A.M Dental Foundation</span>
              <address>
              #37, Plot No:151,<br>
              Mahalakshmi st., T. Nagar,<br>
              chennai-17.<br>
              <abbr title="Phone">Ph:</abbr> (123) 456-7890
              </address>
            </div>
            <div class="pull-right">
              <h2>Invoice</h2>
            </div>
            <div class="clearfix"></div>
            <br>
            
            
            <div class="row">
              <div class="col-md-9"><br>
			  <p>Patient Name: <strong>Ram Kumar</strong></p>
			  <p>Doctor Name: <strong>Vivek Anandan</strong></p>
                
              </div>
              <div class="col-md-3"> <br>
                <div>
                  <div class="pull-left"> INVOICE NO : </div>
                  <div class="pull-right"> 000985 </div>
                  <div class="clearfix"></div>
                </div>
                <div>
                  <div class="pull-left"> INVOICE DATE : </div>
                  <div class="pull-right"> 15/02/13 </div>
                  <div class="clearfix"></div>
                </div>
                <br>
                <div class="well well-small green">
                  <div class="pull-left"> Total Due : </div>
                  <div class="pull-right"> 84,000 INR </div>
                  <div class="clearfix"></div>
                </div>
              </div>
            </div>
            <table class="table">
              <thead>
                <tr>
                  <th style="width:60px" class="unseen text-center">S.No</th>
                  <th class="text-left">Drug</th>
				  <th style="width:60px" class="unseen text-center">EXPIRY</th>
				  <th style="width:60px" class="unseen text-center">QTY</th>
				  <th style="width:60px" class="unseen text-center">TAX</th>
                  <th style="width:140px" class="text-right">UNIT PRICE</th>
                  <th style="width:100px" class="text-right">TOTAL</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="unseen text-center">1</td>
                  <td>Tab. Reeb-D</td>
				  <td>27/07/2017</td>
				  <td class="text-center">5</td>
				  <td class="text-center">2%</td>
                  <td class="text-right">Rs. 749.00</td>
                  <td class="text-right">Rs. 749.00</td>
                </tr>
                <tr>
                  <td class="unseen text-center">2</td>
                  <td>Tab. Hifen-LXX 200</td>
				  <td>18/02/2018</td>
				  <td class="text-center">15</td>
				  <td class="text-center">2%</td>
                  <td class="text-right">Rs. 429.00</td>
                  <td class="text-right">Rs. 858.00</td>
                </tr>
                <tr>
				
                  <td></td>
                  <!--  <h5 class="text-right semi-bold">Thank you for your business</h5></td>-->
					<td></td>
					<td></td>
					<td></td>
                  <td class="text-right"><strong>Subtotal</strong></td>
                  <td class="text-right">Rs. 1607.00</td>
                </tr>
                <tr>
				<td colspan="2" rowspan="4" ><h4 class="semi-bold">Terms and conditions</h4>
                    <p>Check the drug as prescribed by respected doctors and also expiry date. We'll not take drugs back again, once it sold. </p>
				<td></td>
				<td></td>
				<td></td>
                  <td class="text-right no-border"><strong>Shipping</strong></td>
                  <td class="text-right">Rs. 0.00</td>
                </tr>
                <tr>
				<td></td>
				<td></td>
				<td></td>
                  <td class="text-right no-border"><strong>VAT Included in Total</strong></td>
                  <td class="text-right">Rs. 0.00</td>
                </tr>
                <tr>
				<td></td>
				<td></td>
				<td></td>
                  <td class="text-center no-border"><div class="well well-small green"><strong>Total</strong></div></td>
                  <td class="text-right"><strong>Rs. 1607.00</strong></td>
                </tr>
              </tbody>
            </table>
            <br>
            <br>
            <h5 class="text-right text-black">Authorized Sign. </h5><br>
            <h5 class="text-right semi-bold text-black"> Kumaraguru</h5>
            <br>
            <br>
          </div>
        </div>
      </div>
      <div class="col-md-1">
        <div class="invoice-button-action-set">
          <p>
            <button class="btn btn-primary" type="button"><i class="fa fa-print"></i></button>
          </p>
          <p>
            <button class="btn " type="button"><i class="fa fa-cloud-download"></i></button>
          </p>
        </div>
      </div>
      </div>
    </div>
  </div>
</div>
<!-- END PAGE -->
<!-- END CONTAINER -->

<script src="assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="assets/js/tabs_accordian.js" type="text/javascript"></script>
<?php include 'templates/footer_includes.php'; ?>

</body>
</html>