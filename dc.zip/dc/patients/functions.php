<?php
ob_start();
session_start(); 
error_reporting(E_ALL & ~E_NOTICE);
include '../db_connection/db.php';
if($_REQUEST['key'] == 'logout')
{
    session_destroy(); 
    header("Location:../index.php");
}
if($_POST['add_patient1'] == 'add_patient1')
{
	echo '<pre>';
	print_R($_POST);
	die;
    mysqli_query($conn, "INSERT INTO patient_details (name) VALUES ('".mysqli_real_escape_string($conn, $_POST['name'])."')");
    $add_team = mysqli_insert_id($conn);
	echo "Team name added!";
    echo '<script type="text/javascript">setTimeout(function(){window.top.location="add-team.php"} , 4000);</script>';
    
}
//Getting state from country selection
if(!empty($_POST["country_id"])) {	
	$sql ="SELECT * FROM state WHERE country_id = '" . $_POST["country_id"] . "'";
	$results = $conn->query($sql);
	?>
		<option value="">Select State</option>
	<?php	foreach($results as $state) { ?>
		<option value="<?php echo $state["state_id"]; ?>"><?php echo $state["state"]; ?></option>
	<?php
		}
}
//Getting patient name from UID in advance tab
if(!empty($_POST["uid_advance"])) {	
	$sql ="SELECT p_fname FROM patient_details WHERE p_uid = '" . $_POST["uid_advance"] . "'";
	$name=$conn->query($sql);
	$row = mysqli_fetch_assoc($name);
	$pname=$row['p_fname'];
	?>
	<input name="p_name" id="p_name" type="text"  class="form-control" value="<?php echo $row['p_fname']; ?>" readonly>
	<?php	
}

if($_POST['add_patient_man'] == 'add_patient_man')
{
	$profilephoto = $_POST['profile'];
	$_POST['p_dob'] = date("Y-m-d", strtotime($_POST['p_dob']));
	$currentDate = date('Y-m-d h:i:s');
	$query = mysqli_query($conn, "INSERT INTO patient_details (p_uid, p_fname, p_mname, p_lname, p_gender, p_dob, p_email, p_address, p_city, p_state, p_country, p_postalcode, p_phone, created, modified) VALUES ('".$_POST['p_uid']."', '".mysqli_real_escape_string($conn, $_POST['p_fname'])."', '".$_POST['p_mname']."', '".mysqli_real_escape_string($conn, $_POST['p_lname'])."', '".$_POST['p_gender']."', '".$_POST['p_dob']."', '".$_POST['form1Email']."', '".$_POST['p_address']."', '".$_POST['p_city']."', '".$_POST['p_state']."', '".$_POST['p_country']."', '".$_POST['p_postalcode']."', '".$_POST['p_phone']."', '".$currentDate."', '".$currentDate."')") or die(mysqli_error($conn));
	if($query) {	
		$last_insert_id = mysqli_insert_id($conn);
        $userId = $last_insert_id;
		//$employeePhoto = base64_to_jpeg($_POST['profile'], '../assets/img/user/'.$userId.'-employeePhoto.jpg');
		if(1){
			echo "Patient details saved !";
			//echo '<script type="text/javascript">setTimeout(function(){window.top.location="patients_list.php"} , 3000);</script>';
		}
	}
}


if($_POST['add_advance_patient_man'] == 'add_advance_patient_man')
{
	$puid = $_POST['p_uid'];
    $pbloodgrp = $_POST['p_bloodgrp'];
    $poccupation = $_POST['p_occupation'];
    $pmarrystatus = $_POST['p_marrystatus'];
    $preligion = $_POST['p_religion'];
    $pworkaddr = $_POST['p_workaddr'];
	$preferredby = $_POST['p_referredby'];
	$pinsureno = $_POST['p_insure_no'];
	$pspousename = $_POST['p_spousename'];
	$pfax = $_POST['p_fax'];
	$pguardname = $_POST['p_guardname'];
	$pguardnum = $_POST['p_guardnum'];
	$premarks = $_POST['p_remarks'];
	$pspclins = $_POST['p_spcl_ins'];
	$firsttimevisit = $_POST['first_visit'];
    $currentDate = date('Y-m-d h:i:s');

    $puid = mysqli_real_escape_string($conn,$puid);
    $pbloodgrp = mysqli_real_escape_string($conn,$pbloodgrp);
    $poccupation = mysqli_real_escape_string($conn,$poccupation);
    $pmarrystatus = mysqli_real_escape_string($conn,$pmarrystatus);
    $preligion = mysqli_real_escape_string($conn,$preligion);
    $pworkaddr = mysqli_real_escape_string($conn,$pworkaddr);
	$preferredby = mysqli_real_escape_string($conn,$preferredby);
	$pinsureno = mysqli_real_escape_string($conn,$pinsureno);
	$pspousename = mysqli_real_escape_string($conn,$pspousename);
	$pfax = mysqli_real_escape_string($conn,$pfax);
	$pguardname = mysqli_real_escape_string($conn,$pguardname);
	$pguardnum = mysqli_real_escape_string($conn,$pguardnum);
	$premarks = mysqli_real_escape_string($conn,$premarks);
	$pspclins = mysqli_real_escape_string($conn,$pspclins);
	$first_visit = mysqli_real_escape_string($conn,$first_visit);

    $sql = "UPDATE patient_details SET p_bloodgroup='".$pbloodgrp."', p_occupation='".$poccupation."', p_martialstatus='".$pmarrystatus."', 
			p_religion='".$preligion."', p_officeaddress='".$pworkaddr."', p_referredby='".$preferredby."',
			p_insurancenumber='".$pinsureno."', p_spousename='".$pspousename."', p_fax='".$pfax."',
			p_guardianname='".$pguardname."', p_guardiannumber='".$pguardnum."', p_remarks='".$premarks."',
			p_specialinstructions='".$pspclins."', p_firsttimevisitor='".$firsttimevisit."', modified='".$currentDate."' WHERE p_uid=".$puid;
    $result = mysqli_query($conn,$sql);

    if($result) {
		echo "Patient details Updated!";
		echo '<script type="text/javascript">setTimeout(function(){window.top.location="patients_list.php"} , 3000);</script>';
	}
	
}

?>