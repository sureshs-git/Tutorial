<?php

session_start();

ob_start(); 

include('db.php');

if(!isset($_SESSION['admin'])){ 

   header('location:index.php');

}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Patient Registration</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="assets/plugins/jquery-notifications/css/messenger.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="assets/plugins/jquery-notifications/css/messenger-theme-flat.css" rel="stylesheet" type="text/css" media="screen"/>
<!-- BELOW CSS FILE IS NOT REQUIRED -->
<link href="assets/plugins/jquery-notifications/css/location-sel.css" rel="stylesheet" type="text/css" media="screen"/>
<?php include 'templates/header_includes.php'; ?>
</head>
<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN HEADER -->
<?php include 'templates/header.php'; ?>
<!-- END HEADER --> 
<!-- BEGIN CONTAINER -->
<div class="page-container row"> 
  <!-- BEGIN SIDEBAR -->
  <?php include 'templates/sidebar.php'; ?>
  <a href="#" class="scrollup">Scroll</a>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    
    <div class="clearfix"></div>
    <div class="content">
		<div class="col-md-5">
		<ul class="breadcrumb">
        <li>
          <p>Patients</p>
        </li>
        <li><a href="#" class="active">Patient Registration</a> </li>
      </ul></div>
      <div class="page-title col-md-7"> 
        <h3> <span class="semi-bold">Patient Registration</span></h3>
      </div>  
      
      <div class="row">
        
		<div class="col-md-12">
          <ul class="nav nav-tabs" id="tab-01">
            <li class="active" style="width:523px;"><a href="#mandatorydetails">MANDATORY DETAILS</a></li>
            <li class="" style="width:524px;"><a href="#advanceddetails">ADVANCED DETAILS</a></li>
          </ul>
          <div class="tools"> <a href="javascript:;" class="collapse"></a> <a href="#grid-config" data-toggle="modal" class="config"></a> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> </div>
          <div class="tab-content">
            <div class="tab-pane active" id="mandatorydetails">
              <div class="row column-seperation">
			  
                <div class="grid-body" style="padding: 0 10px;">
			<form id="form_iconic_validation" name="patient_register" action="" method="post">	
              <div class="row column-seperation">
                <div class="col-md-5">
                  <!--<h4>Basic Information</h4> --> <div style="height:20px;">          </div>
				  <div class="row form-row">
						<?php 
						$sql = "SELECT uid FROM patient_details ORDER BY patient_id DESC LIMIT 1";

						$result = $conn->query($sql);
						?>
						<div class="col-md-12">
						 <span class="uidspan1">UID</span>
						<span class="uidspan2">
						<?php if (mysqli_num_rows($result) > 0) {
						while($row = $result->fetch_assoc()) { 
						echo $row['uid']; } } 
						else
						echo 'AMDS/IQDS/001';	
						?>
						</span><br>
						</div>
						
                    </div><br>
                    <div class="row form-row">
                      <div class="col-md-4">
                        <select name="p_title" id="p_title" class="dropdown100">
						<option value="">Select Title</option>
						<option value="Baby">Baby</option>
						<option value="Dr">Dr.</option>
						<option value="Master">Master.</option>
						<option value="Miss">Miss.</option>
						<option value="Mr">Mr.</option>
						<option value="Mrs">Mrs.</option>
						<option value="Ms">Ms</option>
						<option value="Prof">Prof.</option>
					  </select>
                      </div>
					  <div class="col-md-8">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<input name="p_fname" id="p_fname" type="text" class="form-control" placeholder="First Name">
						</div>	
                      </div>
                    </div>
					<div class="row form-row">
					  <div class="col-md-6">
                        <input name="p_mname" id="p_mname" type="text"  class="form-control" placeholder="Middle Name">
                      </div>
                      <div class="col-md-6">
                        <input name="form3LastName" id="p_lname" type="text"  class="form-control" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-4">
					  <select name="p_gender" id="p_gender" class="dropdown100">
						<option value="">Select Gender</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
						<option value="Trans">Trans</option>
					  </select>
						<!--<div class="radio">
                          <input id="male" type="radio" name="gender" id="gender" value="male" checked="checked">
                          <label for="male">Male</label>
                          <input id="female" type="radio" name="gender" id="gender" value="female">
                          <label for="female">Female</label>
                        </div>-->
                      </div>
					  
                      <div class="col-md-8">
                        <div class="input-append success date">
						  <input type="text" class="form-control" id="sandbox-advance" name="p_dob" placeholder="DOB" style="width:109%;">
						  <span class="add-on"><span class="arrow"></span><i class="fa fa-th"></i></span>
						</div>
                      </div> 			
                    </div>
                    <div class="row form-row">
                      <div class="col-md-4">
                        <input name="form3TeleCode" id="form3TeleCode" type="text"  class="form-control" placeholder="+91">
                      </div>
                      <div class="col-md-8">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<input name="p_phone" id="p_phone" type="text"  class="form-control" placeholder="Mobile Number" maxlength="10" onkeypress="return validatemobile(event)" onblur="mobilevalid10();">
						</div>
                      </div>
                    </div>
                </div>
                <div class="col-md-5">				
                  <!--<h4>Postal Information</h4>    -->               <div style="height:20px;">          </div>
                    <div class="row form-row">
                      <div class="col-md-12">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<input name="p_address" id="p_address" type="text"  class="form-control" placeholder="Address">
						</div>
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-6">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<input name="p_city" id="p_city" type="text"  class="form-control" placeholder="City">
						</div>
                      </div>
                      <div class="col-md-6">
					    <div class="input-with-icon right">                                       
							<i class=""></i>
							<select class="dropdown100" name="country_id" id="country_id" onChange="getstate(this.value);" required>
											<option value="">Select Country</option>
											<?php 
											$sql_query1 = mysqli_query($conn,"SELECT * FROM country"); 
											while($row = mysqli_fetch_array($sql_query1)){ ?>
											   <option value = "<?php echo $row["country_id"]; ?>"> <?php echo $row["country"]; ?></option>
										   <?php }  ?>									
							</select>
						</div>
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-8">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<select name="state_id" id="state_id"  class="dropdown100">
							<option value="">Select State</option>
						    </select>
						</div>
                      </div>
                      <div class="col-md-4">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<input name="p_postalcode" id="p_postalcode" type="text"  class="form-control" placeholder="Postal Code" maxlength="6">
						</div>
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-12">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<input type="text" name="form1Email" id="p_email" class="form-control" placeholder="email@address.com">  
						</div>
                      </div>
                    </div>
                </div>
				<div class="col-md-2">
                  <h4>Patient Photo</h4> 
					 <div id="preview"><img src="assets/img/profiles/placeholder.jpg" style="width:100%;"></div>
						<!--<form class="cd-form1 no-pad" id="imageform" name="imageform" method="post" action="functions.php" 
						target="_top" enctype="multipart/form-data">-->
						<input type="file" name="photoimg" id="photoimg" style="width:100%;">
						<!--</form>-->
                </div>
              </div>
			  <div id="confirmation"></div>
				<div class="form-actions"> 
					<div class="" style="text-align: center;">
					  <a class="btn btn-primary btn-cons tip" id="add_new_patient" href="add_patient.php" data-original-title="Click to AddNew Patient !"><i class="icon-ok"></i> Add New</a>
					  <button class="btn btn-success btn-cons tip" type="submit" id="patient_register" data-original-title="Click to save !"><i class="icon-ok"></i> Save</button>
					  <button class="btn btn-white btn-cons tip" type="button" data-original-title="Click to cancel !" onclick="showErrorMessage('Ops! Fill mandatory fields')">Cancel</button>
					  
					  <input type="hidden" id="add_patient" value="add_patient">
					</div>
				</div>
			</form>
            </div>
              </div>
            </div>
            <div class="tab-pane" id="advanceddetails">
              <div class="row">
            <div class="grid-body" style="padding: 0 10px;">
			<form id="form_traditional_validation" action="" method="post">	
              <div class="row column-seperation">
                <div class="col-md-6">
                   <div style="height:20px;">          </div>           
                    <div class="row form-row">
                      <div class="col-md-5">
                      <select name="p_bloodgrp" id="p_bloodgrp" class="dropdown100">
						<option value="">Select Blood Group</option>
						<option value="A+ve">A+ve</option>
						<option value="A-ve">A-ve</option>
						<option value="B+ve">B+ve</option>
						<option value="B-ve">B-ve</option>
						<option value="O+ve">O+ve</option>
						<option value="O-ve">O-ve</option>
						<option value="AB+ve">AB+ve</option>
						<option value="AB-ve">AB-ve</option>
					  </select>
                      </div>
                      <div class="col-md-7">
                        <input name="p_occupation" id="p_occupation" type="text"  class="form-control" placeholder="Occupation">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-5">
						<select name="p_marrystatus" id="p_marrystatus" class="dropdown100">
						<option value="">Select Marital Status</option>
						<option value="Single">Single</option>
						<option value="Married">Married</option>
						<option value="Widower">Widower</option>
						<option value="Divorcee">Divorcee</option>
					  </select>
                      </div>
					  
                      <div class="col-md-7">
						 <input name="p_religion" id="p_religion" type="text"  class="form-control" placeholder="Religion">
                      </div> 			
                    </div>
                    <div class="row form-row">
                      <div class="col-md-12">
					  <textarea id="p_workaddr" placeholder="Enter Patient's Work Address ..." class="form-control" rows="3"></textarea>
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-5">
						<label>First Time Visitor</label>
						<div class="radio">
                          <input id="first_visit" type="radio" name="first_visit" value="Yes" checked="checked">
                          <label for="yes">Yes</label>
                          <input id="first_visit" type="radio" name="first_visit" value="No">
                          <label for="female">No</label>
                        </div>
                      </div>
					  <div class="col-md-7">
						<select name="p_referredby" id="p_referredby" class="dropdown100">
							<option value="">Referred By</option>
						</select>
                      </div>
                    </div>
                </div>
                <div class="col-md-6">				
                  <div style="height:20px;"></div>
                    <div class="row form-row">
                      <div class="col-md-6">
                        <input name="p_spousename" id="p_spousename" type="text"  class="form-control" placeholder="Spouse Name">
                      </div>
                      <div class="col-md-6">
                        <input name="p_fax" id="p_fax" type="text"  class="form-control" placeholder="Fax">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-6">
                        <input name="p_guardname" id="p_guardname" type="text"  class="form-control" placeholder="Guardian Name">
                      </div>
                      <div class="col-md-6">
                        <input name="p_guardnum" id="p_guardnum" type="text"  class="form-control" placeholder="Guardian Mobile">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-12">
                        <textarea id="p_remarks" placeholder="Enter Remarks here..." class="form-control" rows="3"></textarea>
                      </div>
                    </div>
					<div class="row form-row">
                      <div class="col-md-12">
                        <textarea id="p_spcl_ins" placeholder="Special Instructions here..." class="form-control" rows="3"></textarea>
                      </div>
                    </div>
                </div>
				
              </div>
			  <div id="confirmation"></div>
				<div class="form-actions"> 
					<div class="" style="text-align: center;">
					  <button class="btn btn-success btn-cons tip" type="submit" id="patient_register" data-original-title="Click to save !"><i class="icon-ok"></i> Save</button>
					  <button class="btn btn-white btn-cons tip" type="button" data-original-title="Click to cancel !" onclick="showErrorMessage('Ops! Fill mandatory fields')">Cancel</button>
					  <!--<button class="btn btn-danger btn-cons" >Show Error Messsage</button>-->
					  <input type="hidden" id="add_patient" value="add_patient">
					</div>
				</div>
			</form>
            </div>
              </div>
            </div>
           
          </div>
        </div>
		
		<!--<div class="col-md-12">
          <div class="grid simple">
            <div class="grid-title no-border">
			<h4> <span class="semi-bold">General Details</span></h4>
              <div class="tools"> <a href="javascript:;" class="collapse"></a><!-- <a href="#grid-config" data-toggle="modal" class="config"></a> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a>--> <!--</div>
            </div>
            <div class="grid-body">
			<form id="form_iconic_validation" action="" method="post">	
              <div class="row column-seperation">
                <div class="col-md-5">
                  <h4>Basic Information</h4>            
                    <div class="row form-row">
                      <div class="col-md-5">
                        <input name="form3FirstName" id="p_fname" type="text"  class="form-control" placeholder="First Name">
                      </div>
                      <div class="col-md-7">
                        <input name="form3LastName" id="p_lname" type="text"  class="form-control" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-5">
						<div class="radio">
                          <input id="male" type="radio" name="gender" id="gender" value="male" checked="checked">
                          <label for="male">Male</label>
                          <input id="female" type="radio" name="gender" id="gender" value="female">
                          <label for="female">Female</label>
                        </div>
                      </div>
					  
                      <div class="col-md-7">
                        <div class="input-append success date">
						  <input type="text" style="width:97%;" class="form-control" id="sandbox-advance" placeholder="DOB">
						  <span class="add-on"><span class="arrow"></span><i class="fa fa-th"></i></span>
						</div>
                      </div> 			
                    </div>
                    <div class="row form-row">
                      <div class="col-md-5">
                        <input name="bloodgroup" id="p_bloodgrp" type="text"  class="form-control" placeholder="Blood Group">
                      </div>
					  <div class="col-md-7">
                        <input name="form3Occupation" id="p_occupation" type="text"  class="form-control" placeholder="Occupation">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-12">
						<div class="input-with-icon right">                                       
							<i class=""></i>
							<input type="text" name="form1Email" id="form1Email" class="form-control" 
							placeholder="email@address.com">                                 
						</div>
                      </div>
                    </div>
                </div>
                <div class="col-md-5">				
                  <h4>Postal Information</h4>                  
                    <div class="row form-row">
                      <div class="col-md-12">
                        <input name="form3Address" id="p_address" type="text"  class="form-control" placeholder="Address">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-6">
                        <input name="form3City" id="p_city" type="text"  class="form-control" placeholder="City">
                      </div>
                      <div class="col-md-6">
                        <input name="form3State" id="p_state" type="text"  class="form-control" placeholder="State">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-8">
                        <input name="form3Country" id="p_country" type="text"  class="form-control" placeholder="Country">
                      </div>
                      <div class="col-md-4">
                        <input name="form3PostalCode" id="p_postalcode" type="text"  class="form-control" placeholder="Postal Code">
                      </div>
                    </div>
                    <div class="row form-row">
                      <div class="col-md-4">
                        <input name="form3TeleCode" id="form3TeleCode" type="text"  class="form-control" placeholder="+91">
                      </div>
                      <div class="col-md-8">
                        <input name="form3TeleNo" id="p_phone" type="text"  class="form-control" placeholder="Phone Number">
                      </div>
                    </div>
                </div>
				<div class="col-md-2">
                  <h4>Patient Photo</h4>            
					
					 <div id="preview"><img src="assets/img/profiles/placeholder.jpg" style="width:100%;"></div>
						<form class="cd-form1 no-pad" id="imageform" name="imageform" method="post" action="functions.php" 
						target="_top" enctype="multipart/form-data">
						<input type="file" name="photoimg" id="photoimg" style="width:100%;">
                </div>
              </div>
			  <div id="confirmation"></div>
				<div class="form-actions"> 
					<div class="" style="text-align: center;">
					  <a class="btn btn-primary btn-cons tip" id="add_new_patient" href="add_patient.php" data-original-title="Click to AddNew Patient !"><i class="icon-ok"></i> Add New</a>
					  <button class="btn btn-success btn-cons tip" type="submit" id="patient_register" data-original-title="Click to save !"><i class="icon-ok"></i> Save</button>
					  <button class="btn btn-white btn-cons tip" type="button" data-original-title="Click to cancel !" onclick="showErrorMessage('Ops! Fill mandatory fields')">Cancel</button>
					  <!--<button class="btn btn-danger btn-cons" >Show Error Messsage</button>-->
					<!--  <input type="hidden" id="add_patient" value="add_patient">
					</div>
				</div>
			</form>
            </div>
                  <!-- <div class="col-md-6">
              <div class="grid simple">
                <div class="grid-title no-border">
                  <h4>Drag n Drop <span class="semi-bold">Uploader</span></h4>
                  <div class="tools"> <a href="javascript:;" class="expand"></a> <a href="#grid-config" data-toggle="modal" class="config"></a> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> </div>
                </div>
                <div class="grid-body no-border">
                  <div class="row-fluid">
                    <form action="/file-upload" class="dropzone no-margin">
                      <div class="fallback">
                        <input name="file" type="file" multiple />
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>-->
        <!--  </div>
        </div>-->
      </div>
    </div>
  </div>
</div>
<!-- END PAGE -->
<!-- END CONTAINER -->


<script>
    $(document).ready(function(){
		//$.noConflict();
      $("#patient_register").click(function(e){
		e.preventDefault();
		if($.trim($('#p_fname').val()) == ''){
			$('#p_fname').addClass('warn').focus();
			return false;	   
			} 
			else if($.trim($('#p_lname').val()) == ''){
			$('#p_fname').removeClass('warn');
			$('#p_lname').addClass('warn').focus();
			return false;	   
			} 
			else if($.trim($('#p_gender').val()) == ''){
			$('#p_lname').removeClass('warn');
			$('#p_gender').addClass('warn').focus();
			return false;	   
			}
			else if($.trim($('#sandbox-advance').val()) == ''){
			$('#p_gender').removeClass('warn');
			$('#sandbox-advance').addClass('warn').focus();
			return false;
			}
			else if($.trim($('#p_phone').val()) == ''){
			$('#sandbox-advance').removeClass('warn');
			$('#p_phone').addClass('warn').focus();
			return false;	   
			}
			else if($.trim($('#form1Email').val()) == ''){
			$('#p_phone').removeClass('warn');
			$('#form1Email').addClass('warn').focus();
			return false;
			}
			else
			{
			if($.trim($('#form1Email').val()) != ''){	
			$('#form1Email').removeClass('warn');
			}
			var gen = $("input[name='gender']:checked").val();
		$('#add_new_patient').attr('disabled', 'disabled').css({"opacity": "0.3","cursor": "none"});	
        $.ajax({type: "POST",
                url: "functions.php",
                data: { p_fname: $("#p_fname").val(), p_lname: $("#p_lname").val(), p_gender: gen, p_dob: $("#sandbox-advance").val(), p_bloodgrp: $("#p_bloodgrp").val(),p_occupation: $("#p_occupation").val(), p_email:$("#form1Email").val(), p_address: $("#p_address").val(), p_city: $("#p_city").val(), p_state: $("#p_state").val(), p_country: $("#p_country").val(), p_postalcode: $("#p_postalcode").val(), p_phone:$("#p_phone").val(), add_patient: $("#add_patient").val() },
                success:function(result){
          $("#confirmation").html(result).css({"font-size": "150%","text-align": "center", "color": "green", "margin": "5px"}).fadeOut(3000);
        }});
			}
      });
    });
</script>
<script type="text/javascript">
$(document).ready(function() 
 { 
 $.noConflict();
$("#photoimg").live('change', function () {
     //Get count of selected files
     var countFiles = $(this)[0].files.length;

     var imgPath = $(this)[0].value;
     var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
     var image_holder = $("#preview");
     image_holder.empty();

     if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
         if (typeof (FileReader) != "undefined") {

             //loop for each file selected for uploaded.
             for (var i = 0; i < countFiles; i++) {

                 var reader = new FileReader();
                 reader.onload = function (e) {
                     $("<img />", {
                         "src": e.target.result,
                             "class": "preview"
                     }).appendTo(image_holder);
                 }

                 image_holder.show();
                 reader.readAsDataURL($(this)[0].files[i]);
             }

         } else {
             alert("This browser does not support FileReader.");
         }
     } else {
         alert("Pls select only images");
     }
 });
  });
  </script>
<script>
function getstate(val) { 
	$.ajax({
	type: "POST",
	url: "get_state.php",
	data:'country_id='+val,
	success: function(data){
		$("#state_id").html(data);
	}
	});
}
function validatemobile(key)
{
//getting key code of pressed key
var keycode = (key.which) ? key.which : key.keyCode;
var phn = document.getElementById('p_phone');
//comparing pressed keycodes
if (!(keycode==8 || keycode==46)&&(keycode < 48 || keycode > 57))
{
alert("Please Type Numbers Only.");
return false;
}
}
function mobilevalid10(){
//Condition to check textbox contains ten numbers or not
var phn = document.getElementById('p_phone');
if (phn.value.length <10)
{ alert("Enter 10 digit number."); return true; }
}
</script>
<?php include 'templates/footer_includes.php'; ?>
<script src="assets/plugins/jquery-notifications/js/messenger.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-notifications/js/messenger-theme-future.js" type="text/javascript"></script>
<!-- JS ONY FOR DEMO--> 	
<script type="text/javascript" src="assets/plugins/jquery-notifications/js/demo/location-sel.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-notifications/js/demo/theme-sel.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-notifications/js/demo/demo.js"></script>
<script type="text/javascript" src="assets/js/notifications.js"></script>
<script src="assets/js/jquery-1.8.3.min.js" type="text/javascript"></script>
</body>
</html>