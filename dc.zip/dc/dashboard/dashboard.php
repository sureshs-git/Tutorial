<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>A M Dental Clinic - Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />
    
<link href="../assets/plugins/jquery-metrojs/MetroJs.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="../assets/plugins/shape-hover/css/demo.css" />
<link rel="stylesheet" type="text/css" href="../assets/plugins/shape-hover/css/component.css" />
<link rel="stylesheet" type="text/css" href="../assets/plugins/owl-carousel/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="../assets/plugins/owl-carousel/owl.theme.css" />
<link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="../assets/plugins/jquery-slider/css/jquery.sidr.light.css" rel="stylesheet" type="text/css" media="screen"/>
<link rel="stylesheet" href="../assets/plugins/jquery-ricksaw-chart/css/rickshaw.css" type="text/css" media="screen" >
<link rel="stylesheet" href="../assets/plugins/Mapplic/mapplic/mapplic.css" type="text/css" media="screen" >
<!-- BEGIN CORE CSS FRAMEWORK -->
<link href="../assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<!-- END CORE CSS FRAMEWORK -->

<!-- BEGIN CSS TEMPLATE -->
<link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/magic_space.css" rel="stylesheet" type="text/css"/>
<!-- END CSS TEMPLATE -->

</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN HEADER -->
<?php include '../templates/header.php'; ?>
<!-- END HEADER -->
<!-- BEGIN CONTAINER -->
<div class="page-container row-fluid">
  <!-- BEGIN SIDEBAR -->
  <?php include '../templates/sidebar.php'; ?>
  <!-- END SIDEBAR -->
  <!--<div class="footer-widget">
    <div class="progress transparent progress-small no-radius no-margin">
      <div data-percentage="79%" class="progress-bar progress-bar-success animate-progress-bar" ></div>
    </div>
    <div class="pull-right">
      <div class="details-status"> <span data-animation-duration="560" data-value="86" class="animate-number"></span>% </div>
      <a href="lockscreen.html"><i class="fa fa-power-off"></i></a></div>
  </div>-->
  <!-- END SIDEBAR -->
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
    <div id="portlet-config" class="modal hide">
      <div class="modal-header">
        <button data-dismiss="modal" class="close" type="button"></button>
        <h3>Widget Settings</h3>
      </div>
      <div class="modal-body"> Widget settings form goes here </div>
    </div>
    <div class="clearfix"></div>
    <div class="content sm-gutter" style="padding-top:60px;">
	
      <div class="page-title">
      </div>
	   <!-- BEGIN DASHBOARD TILES -->
	  <div class="row">	
		<div class="col-md-4 col-vlg-3 col-sm-6">
			<div class="tiles green m-b-10">
              <div class="tiles-body"  style="background-color:#FE5722;">
			  <div class="controller"> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> </div>
                <div class="tiles-title text-black">OVERALL REVENUE </div>
			         <div class="widget-stats">
                      <div class="wrapper transparent"> 
						<span class="item-title">Overall Visits</span> <span class="item-count animate-number semi-bold" data-value="2415" data-animation-duration="700">0</span>
					  </div>
                    </div>
                    <div class="widget-stats">
                      <div class="wrapper transparent">
						<span class="item-title">Today's</span> <span class="item-count animate-number semi-bold" data-value="751" data-animation-duration="700">0</span> 
					  </div>
                    </div>
                    <div class="widget-stats ">
                      <div class="wrapper last"> 
						<span class="item-title">Monthly</span> <span class="item-count animate-number semi-bold" data-value="1547" data-animation-duration="700">0</span> 
					 </div>
                    </div>
                    <div class="progress transparent progress-small no-radius m-t-20" style="width:90%">
                      <div class="progress-bar progress-bar-white animate-progress-bar" data-percentage="64.8%" ></div>
                    </div>
                    <div class="description"> <span class="text-white mini-description ">4% higher <span class="blend">than last month</span></span></div>
			  </div>			
			</div>	
	

		</div>
		<div class="col-md-4 col-vlg-3 col-sm-6">
			<div class="tiles blue m-b-10">
              <div class="tiles-body">
			  <div class="controller"> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> </div>
                <div class="tiles-title text-black">OVERALL PATIENTS VISITS </div>
			         <div class="widget-stats">
                      <div class="wrapper transparent"> 
						<span class="item-title">Overall Visits</span> <span class="item-count animate-number semi-bold" data-value="15489" data-     animation-duration="700">0</span>
					  </div>
                    </div>
                    <div class="widget-stats">
                      <div class="wrapper transparent">
						<span class="item-title">Today's</span> <span class="item-count animate-number semi-bold" data-value="551" data-animation-duration="700">0</span> 
					  </div>
                    </div>
                    <div class="widget-stats ">
                      <div class="wrapper last"> 
						<span class="item-title">Monthly</span> <span class="item-count animate-number semi-bold" data-value="1450" data-animation-duration="700">0</span> 
					 </div>
                    </div>
                    <div class="progress transparent progress-small no-radius m-t-20" style="width:90%">
                      <div class="progress-bar progress-bar-white animate-progress-bar" data-percentage="54%" ></div>
                    </div>
                    <div class="description"> <span class="text-white mini-description ">4% higher <span class="blend">than last month</span></span></div>
			  </div>			
			</div>	
		</div>
		<div class="col-md-4 col-vlg-3 col-sm-6">
			<div class="tiles purple m-b-10">
              <div class="tiles-body" style="background-color:#59ec0e;">
			  <div class="controller"> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> </div>
                <div class="tiles-title text-black">CLINIC PURCHASE SCORE BY I.Q.D.S </div>
			         <div class="widget-stats">
                      <div class="wrapper transparent"> 
						<span class="item-title">Overall Load</span> <span class="item-count animate-number semi-bold" data-value="5695" data-animation-duration="700">0</span>
					  </div>
                    </div>
                    <div class="widget-stats">
                      <div class="wrapper transparent">
						<span class="item-title">Today's</span> <span class="item-count animate-number semi-bold" data-value="568" data-animation-duration="700">0</span> 
					  </div>
                    </div>
                    <div class="widget-stats ">
                      <div class="wrapper last"> 
						<span class="item-title">Monthly</span> <span class="item-count animate-number semi-bold" data-value="12459" data-animation-duration="700">0</span> 
					 </div>
                    </div>
                    <div class="progress transparent progress-small no-radius m-t-20" style="width:90%">
                      <div class="progress-bar progress-bar-white animate-progress-bar" data-percentage="90%" ></div>
                    </div>
                    <div class="description"> <span class="text-white mini-description ">4% higher <span class="blend">than last month</span></span></div>
			  </div>			
			</div>	
		</div>
<!--<div class="col-md-4 col-vlg-4 m-b-10 ">-->

		<!--<div class="col-md-4 col-vlg-3 visible-xlg visible-sm col-sm-6">
			<div class="tiles red m-b-10">
              <div class="tiles-body">
			  <div class="controller"> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> </div>
                <div class="tiles-title text-black">OVERALL SALES </div>
			         <div class="widget-stats">
                      <div class="wrapper transparent"> 
						<span class="item-title">Overall Sales</span> <span class="item-count animate-number semi-bold" data-value="5669" data-animation-duration="700">0</span>
					  </div>
                    </div>
                    <div class="widget-stats">
                      <div class="wrapper transparent">
						<span class="item-title">Today's</span> <span class="item-count animate-number semi-bold" data-value="751" data-animation-duration="700">0</span> 
					  </div>
                    </div>
                    <div class="widget-stats ">
                      <div class="wrapper last"> 
						<span class="item-title">Monthly</span> <span class="item-count animate-number semi-bold" data-value="1547" data-animation-duration="700">0</span> 
					 </div>
                    </div>
                    <div class="progress transparent progress-small no-radius m-t-20" style="width:90%">
                      <div class="progress-bar progress-bar-white animate-progress-bar" data-percentage="64.8%" ></div>
                    </div>
                    <div class="description"> <span class="text-white mini-description ">4% higher <span class="blend">than last month</span></span></div>
			  </div>			
			</div>	
		</div>-->		
	 </div>
	  <!-- END DASHBOARD TILES -->
      <div class="row" >
	  <div class="col-md-4 col-vlg-3 col-sm-6">
			<div class="tiles white">
			  <div class="row">
				<div class="sales-graph-heading">
				<div class="col-md-5 col-sm-5">
				  <h5 class="no-margin">You have earned</h5>
				  <h4><span class="item-count animate-number semi-bold" data-value="21451" data-animation-duration="700">0</span> USD</h4>
				</div>
				<div class="col-md-3 col-sm-3">
				  <p class="semi-bold">TODAY</p>
				  <h4><span class="item-count animate-number semi-bold" data-value="451" data-animation-duration="700">0</span> USD</h4>
				</div>
				<div class="col-md-4 col-sm-3">
				  <p class="semi-bold">THIS MONTH</p>
				  <h4><span class="item-count animate-number semi-bold" data-value="8514" data-animation-duration="700">0</span> USD</h4>
				</div>
				<div class="clearfix"></div>
			  </div>
			  </div>
			  <h5 class="semi-bold m-t-30 m-l-30">LAST SALE</h5>
			  <table class="table no-more-tables m-t-20 m-l-20 m-b-30">
				<thead style="display:none">
				  <tr>
					<th style="width:9%">Project Name</th>
					<th style="width:22%">Description</th>
					<th style="width:6%">Price</th>
					<th style="width:1%"> </th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<td class="v-align-middle bold text-success">25601</td>
					<td class="v-align-middle"><span class="muted">Redesign project template</span> </td>
					<td><span class="muted bold text-success">$4,500</span> </td>
					<td class="v-align-middle"></td>
				  </tr>
				  <tr>
					<td class="v-align-middle bold text-success">25601</td>
					<td class="v-align-middle"><span class="muted">Redesign project template</span> </td>
					<td><span class="muted bold text-success">$4,500</span> </td>
					<td class="v-align-middle"></td>
				  </tr>
				</tbody>
			  </table>
			  <div id="sales-graph"> </div>
			</div>
        </div>
		<!-- BEGIN WORLD MAP WIDGET - MAP -->
        <div class="col-md-4 col-vlg-8 m-b-10">
          <div class="row" >
            <div class="col-md-12" data-sync-height="true">
            <!--<div class="col-md-7 col-vlg-8 col-sm-8 no-padding -height" >
              <div class="tiles green" id="mapplic_demo">
              </div>
              <div class="clearfix"></div>
            </div>-->
            <div class="col-md-12 col-vlg-4 col-sm-4 no-padding" >
              <div class="tiles black" >
                <div class="tiles-body">
                  <h5 class="text-white"><span class="semi-bold">TOTAL</span> OUTSTANDING PAYMENT</h5>
                  <input type="text" placeholder="Search..." class="form-control input-sm m-t-20">
                  <div class="m-t-30">
                    <div class="widget-stats">
                      <div class="wrapper"> <span class="item-title">Overall Visits</span> <span class="item-count animate-number semi-bold" data-value="2415" data-animation-duration="700">0</span> </div>
                    </div>
                    <div class="widget-stats">
                      <div class="wrapper"> <span class="item-title">Today's</span> <span class="item-count animate-number semi-bold" data-value="751" data-animation-duration="700">0</span> </div>
                    </div>
                    <div class="widget-stats hidden-sm">
                      <div class="wrapper last"> <span class="item-title">Monthly</span> <span class="item-count animate-number semi-bold" data-value="1547" data-animation-duration="700">0</span> </div>
                    </div>
                    <div class="progress transparent progress-small no-radius m-t-20" style="width:90%">
                      <div class="progress-bar progress-bar-success animate-progress-bar" data-percentage="64.8%" ></div>
                    </div>
                    <div class="description"> <span class="text-white mini-description ">4% higher <span class="blend">than last month</span></span></div>
                  </div>
                </div>
                <div id="chart" style="height:123px"> </div>
              </div>
            </div>
            </div>
          </div>
        </div>
        <!-- END WORLD MAP WIDGET - CRAFT MAP -->
		<div class="col-md-4 col-sm-4 m-b-10" data-aspect-ratio="tru" style="height:370px !important;">
              <div class="live-tile slide ha " data-speed="750" data-delay="4000" data-mode="carousel">
                <div class="slide-front ha tiles blue"  style="background-color:gray;">
                  <div class="p-t-20 p-l-20 p-r-20 p-b-20">
                    <h4 class="text-white no-margin custom-line-height">“Just <span class="semi-bold">Completed</span> the <span class="semi-bold">Heart walk</span> advertiing 
                      campaign”</h4>
                  </div>
                  <div class="overlayer bottom-left fullwidth">
                    <div class="overlayer-wrapper">
                      <div class="user-comment-wrapper">
                        <div class="profile-wrapper"> <img src="../assets/img/profiles/avatar_small.jpg" alt="" data-src="../assets/img/profiles/avatar_small.jpg" data-src-retina="assets/img/profiles/avatar_small2x.jpg" width="35" height="35"> </div>
                        <div class="comment">
                          <div class="user-name text-white "><span class="bold"> I.Q.D.S</span>  </div>
                          <!--<p class="text-white-opacity">@ Revox</p>-->
                        </div>
                        <div class="clearfix"></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="slide-back ha tiles blue">
                  <div class="user-comment-wrapper m-t-20">
                    <div class="profile-wrapper"> <img src="../assets/img/profiles/d.jpg" alt="" data-src="../assets/img/profiles/d.jpg" data-src-retina="assets/img/profiles/d2x.jpg" width="35" height="35"> </div>
                    <div class="comment">
                      <div class="user-name text-white "><span class="bold"> I.Q.D.S</span> </div>
                      <!--<p class="text-white-opacity">@ Revox</p>-->
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="overlayer bottom-left fullwidth">
                    <div class="overlayer-wrapper">
                      <div class="p-t-20 p-l-20 p-r-20 p-b-20">
                        <h4 class="text-white no-margin custom-line-height">“Just <span class="semi-bold">Completed</span> the <span class="semi-bold">Heart walk</span> adverting 
                          campaign”</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
			  
            </div>
			
		<!-- BEGIN REALTIME SALES GRAPH -->
		
		<!-- END REALTIME SALES GRAPH -->
	  </div><H5 style="text-align:center;font-weight:bold;">AN INITIATIVE OF <a href="">I.Q.D.S PVT. LTD.</a> CHENNAI, INDIA.</H5>
	   </div>
		  </div>		  
</div>

<!-- END CONTAINER -->
<!-- BEGIN CORE JS FRAMEWORK-->
    
<!--[if lt IE 9]>
<script src="assets/plugins/respond.js"></script>
<![endif]-->

<script src="../assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="../assets/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/plugins/breakpoints.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-lazyload/jquery.lazyload.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<!-- END CORE JS FRAMEWORK -->
<!-- BEGIN PAGE LEVEL JS -->
<script src="../assets/plugins/jquery-slider/jquery.sidr.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-ricksaw-chart/js/raphael-min.js"></script>
<script src="../assets/plugins/jquery-ricksaw-chart/js/d3.v2.js"></script>
<script src="../assets/plugins/jquery-ricksaw-chart/js/rickshaw.min.js"></script>
<script src="../assets/plugins/jquery-sparkline/jquery-sparkline.js"></script>
<script src="../assets/plugins/skycons/skycons.js"></script>
<script src="../assets/plugins/owl-carousel/owl.carousel.min.js" type="text/javascript"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script src="../assets/plugins/jquery-gmap/gmaps.js" type="text/javascript"></script>
<script src="../assets/plugins/Mapplic/js/jquery.easing.js" type="text/javascript"></script>
<script src="../assets/plugins/Mapplic/js/jquery.mousewheel.js" type="text/javascript"></script>
<script src="../assets/plugins/Mapplic/js/hammer.js" type="text/javascript"></script>
<script src="../assets/plugins/Mapplic/mapplic/mapplic.js" type="text/javascript"></script>
    
<script src="../assets/plugins/jquery-flot/jquery.flot.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-flot/jquery.flot.resize.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-metrojs/MetroJs.min.js" type="text/javascript" ></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN CORE TEMPLATE JS -->
<script src="../assets/js/core.js" type="text/javascript"></script>
<script src="../assets/js/chat.js" type="text/javascript"></script>
<script src="../assets/js/demo.js" type="text/javascript"></script>
<script src="../assets/js/dashboard_v2.js" type="text/javascript"></script>
<script type="text/javascript">
        $(document).ready(function () {
            $(".live-tile,.flip-list").liveTile();
        });
</script>

<!-- END CORE TEMPLATE JS -->
</body>
</html>
