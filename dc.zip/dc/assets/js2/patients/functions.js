	//Get state
	function getstate(val) { 
		$.ajax({
		type: "POST",
		url: "functions.php",
		data:'country_id='+val,
		success: function(data){
			$("#state_id").html(data);
		}
		});
	}
	//Get patient name in advance tab
	function getname(val) { 
		$.ajax({
		type: "POST",
		url: "functions.php",
		data:'uid_advance='+val,
		success: function(data){
			$("#p_name_adv").html(data);
		}
		});
	}
	
	//Begin - Mobile number validate
	function charonly(key)
	{		
		var keycode = (key.which) ? key.which : key.keyCode; //getting key code of pressed key
		if (!(keycode==8 || keycode==46)&&(keycode < 48 || keycode > 57)) //comparing pressed keycodes
		{
		alert("Please Type Numbers Only.");
		return false;
		}
	}
	function mobilevalid10(){
	var phn = document.getElementById('p_phone');
	if (phn.value.length <10) //Condition to check textbox contains 10 numbers or not
	{ alert("Enter 10 digit number."); document.getElementById('p_phone').focus(); return true; }
	}
	//End - mobile number validate
	$("#reset").click(function () {
		$('#p_basic_profile')[0].reset();
	 });
	 $("#reset_adv").click(function () {
		$('#p_advance_profile')[0].reset();
	 });
	
	//postal code validate
	function zipvalid6(){
	var phn = document.getElementById('p_postalcode');
	if (phn.value.length <6)//Condition to check textbox contains 6 numbers or not
	{ alert("Enter 6 digit number."); document.getElementById('p_postalcode').focus(); return true; }
	}
	
	var base64url = '';
	$('#p_dob').datepicker({
			format: "dd/mm/yyyy",
			startView: 1,
			daysOfWeekDisabled: "3,4",
			autoclose: true,
			todayHighlight: true
    });
	
	function EL(id) { return document.getElementById(id); } // Get el by ID helper function

    function readFile() {
        if (this.files && this.files[0]) {
			$('#sampleimg').hide();
			$('#photo_error').hide();
			$('#img').show();
            var FR= new FileReader();
            FR.onload = function(e) {
                EL("img").src = e.target.result;
                base64url = e.target.result;
            };
            FR.readAsDataURL( this.files[0] );
        }
    }
    EL("photoimg").addEventListener("change", readFile, false);
	
	var first_visit_val= '';
	$("input:radio").click(function(){							
		if( $(this).is(":checked") ){
			first_visit_val = $(this).val();			
		}
	});						
						
						
	$('#p_basic_profile').validate({
                errorElement: 'span', 
                errorClass: 'error', 
                focusInvalid: false, 
                ignore: "",
                rules: {
                    p_fname: {
                        required: true
                    },
					p_gender: {
                        required: true
                    },
					p_dob: {
                        required: true
                    }, 
					p_phone: {
                        required: true
                    },
					p_address: {
                        required: true
                    },
					p_city: {
                        required: true
                    },
					country_id: {
                        required: true
                    },
					state_id: {
                        required: true
                    },
					p_postalcode: {
                        required: true
                    },
                    form1Email: {
                        required: true,
                        email: true
                    },
                    form1Url: {
                        required: true,
                        url: true
                    },
                    gendericonic:{
                        required: true
                    }
                },

                invalidHandler: function (event, validator) {
					//display error alert on form submit    
                },

                errorPlacement: function (error, element) { // render error placement for each input type
                    var icon = $(element).parent('.input-with-icon').children('i');
                    var parent = $(element).parent('.input-with-icon');
                    icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  
                    parent.removeClass('success-control').addClass('error-control');  
                },

                highlight: function (element) { // hightlight error inputs
					var parent = $(element).parent();
                    parent.removeClass('success-control').addClass('error-control'); 
                },

                unhighlight: function (element) { // revert the change done by hightlight
                    
                },

                success: function (label, element) {
                    var icon = $(element).parent('.input-with-icon').children('i');
					var parent = $(element).parent('.input-with-icon');
                    icon.removeClass("fa fa-exclamation").addClass('fa fa-check-circle');
					parent.removeClass('error-control').addClass('success-control'); 
                },

                submitHandler: function (form) {	
					var image_exists = $('#img').attr('src');
					var profileImage = $('#photoimg');
					
					if(image_exists == null || image_exists == '') {
						if ($.trim(profileImage.val()) == '') {
							profileImage.addClass('errorBorder');
							$(".photo_error").show();
							$(".photo_error").html("Select Profile Photo");
							profileImage.focus();
							error = true;
						}
						if ($.trim(profileImage.val()) != '') {
							profileImage.removeClass('errorBorder');
							$(".photo_error").hide();
							error = false;
						}
					}
					
					if(image_exists != ''){
						base64url = image_exists;
					
					
						var data = {
								p_uid : $('#p_uid').val(),
								p_fname : $('#p_fname').val(),
								p_mname : $('#p_mname').val(),
								p_lname : $('#p_lname').val(),
								p_gender : $('#p_gender').val(),
								p_dob : $('#p_dob').val(),
								form1Email : $('#p_email').val(),
								p_address : $('#p_address').val(),
								p_city : $('#p_city').val(),
								p_state : $('#state_id').val(),
								p_country : $('#country_id').val(),
								p_postalcode : $('#p_postalcode').val(),
								p_phone : $('#p_phone').val(),
								add_patient_man : $('#add_patient_man').val(),
								profile : base64url							
							};
							
						$('#add_new_patient').attr('disabled', 'disabled').css({"opacity": "0.3","cursor": "none"});	
						$.ajax({
								type: "POST",
								url: "functions.php",
								data: data,
								success:function(result)
								{
									$("#confirmation").html(result).css({"font-size": "150%","text-align": "center", "color": "green", "margin": "5px"}).fadeOut(3000);
									$(".page-content").hide('slide', {direction: 'left' }, 4000);
									
								},
								error: function ()
								{
								}
						}); 
					}
                }
           
            });
			
			
			
			$('#p_advance_profile').validate({
                errorElement: 'span', 
                errorClass: 'error', 
                focusInvalid: false, 
                ignore: "",
                rules: {
                    uid_advance: {
                        required: true
                    }
                },

                invalidHandler: function (event, validator) {
					//display error alert on form submit    
                },

                errorPlacement: function (error, element) { // render error placement for each input type
                    var icon = $(element).parent('.input-with-icon').children('i');
                    var parent = $(element).parent('.input-with-icon');
                    icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  
                    parent.removeClass('success-control').addClass('error-control');  
                },

                highlight: function (element) { // hightlight error inputs
					var parent = $(element).parent();
                    parent.removeClass('success-control').addClass('error-control'); 
                },

                unhighlight: function (element) { // revert the change done by hightlight
                    
                },

                success: function (label, element) {
                    var icon = $(element).parent('.input-with-icon').children('i');
					var parent = $(element).parent('.input-with-icon');
                    icon.removeClass("fa fa-exclamation").addClass('fa fa-check-circle');
					parent.removeClass('error-control').addClass('success-control'); 
                },

                submitHandler: function (form) {
					
						var data = {
								p_uid : $('#uid_advance').val(),
								p_bloodgrp : $('#p_bloodgrp').val(),
								p_occupation : $('#p_occupation').val(),
								p_marrystatus : $('#p_marrystatus').val(),
								p_religion : $('#p_religion').val(),
								p_workaddr : $('#p_workaddr').val(),
								p_referredby : $('#p_referredby').val(),
								p_insure_no : $('#p_insure_no').val(),
								p_spousename : $('#p_spousename').val(),
								p_fax : $('#p_fax').val(),
								p_guardname : $('#p_guardname').val(),
								p_guardnum : $('#p_guardnum').val(),
								p_remarks : $('#p_remarks').val(),
								p_spcl_ins : $('#p_spcl_ins').val(),
								add_advance_patient_man : $('#add_advance_patient_man').val(),
								first_visit : first_visit_val							
							};
							
						//$('#add_new_patient').attr('disabled', 'disabled').css({"opacity": "0.3","cursor": "none"});	
						$.ajax({
								type: "POST",
								url: "functions.php",
								data: data,
								success:function(result)
								{
									$("#confirmation").html(result).css({"font-size": "150%","text-align": "center", "color": "green", "margin": "5px"}).fadeOut(3000);
									$(".page-content").hide('slide', {direction: 'left' }, 4000);
									
								},
								error: function ()
								{
								}
						});  
					
                }
           
            });
			
			
			
             $('.select2', "#p_basic_profile").change(function () {
                $('#p_basic_profile').validate().element($(this)); //revalidate the chosen dropdown value and show error or success message for the input
            });



//Form submit
   /*$(document).ready(function(){	   
		//$.noConflict();
      $("#p_basic_profile").submit(function(e){ 	  
	//$(document).on("submit", "#p_basic_profile", function(e) {
		
			e.preventDefault();
			var data = {
				p_uid : $('#p_uid').val(),
                p_fname : $('#p_fname').val(),
				p_mname : $('#p_mname').val(),
                p_lname : $('#p_lname').val(),
				p_gender : $('#p_gender').val(),
				p_dob : $('#sandbox-advance').val(),
				form1Email : $('#p_email').val(),
				p_address : $('#p_address').val(),
				p_city : $('#p_city').val(),
				p_state : $('#state_id').val(),
				p_country : $('#country_id').val(),
				p_postalcode : $('#p_postalcode').val(),
				p_phone : $('#p_phone').val(),
				add_patient_man : $('#add_patient_man').val()                
            };
			
			$('#add_new_patient').attr('disabled', 'disabled').css({"opacity": "0.3","cursor": "none"});	
			$.ajax({
					type: "POST",
					url: "functions.php",
					data: data,
					success:function(result)
					{
						$("#confirmation").html(result).css({"font-size": "150%","text-align": "center", "color": "green", "margin": "5px"}).fadeOut(3000);
					},
					error: function ()
					{
					}
			});
		});
    });  */