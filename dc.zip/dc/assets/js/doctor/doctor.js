	$('#rootwizard').bootstrapWizard({
		'tabClass': 'form-wizard',
		'onNext': function(tab, navigation, index) {
			var $valid = $("#doctor_profile_details").valid();
			if(!$valid) {
				$validator.focusInvalid();
				return false;
			}
			else{
				$('#rootwizard').find('.form-wizard').children('li').eq(index-1).addClass('complete');
				$('#rootwizard').find('.form-wizard').children('li').eq(index-1).find('.step').html('<i class="fa fa-check"></i>');	
			}
		}
	});	
	
	//Begin - Mobile number validate
	function charonly(key)
	{		
		var keycode = (key.which) ? key.which : key.keyCode; //getting key code of pressed key
		if (!(keycode==8 || keycode==46)&&(keycode < 48 || keycode > 57)) //comparing pressed keycodes
		{
		alert("Please Type Numbers Only.");
		return false;
		}
	}
	function mobilevalid(){
		var phn = $('#d_mobileno').val();
		if (phn.length <10) //Condition to check textbox contains 10 numbers or not
		{ 
			alert("Enter 10 digit number."); 
			$('#d_mobileno').focus(); return true; 
		}
	}
	
	//End - mobile number validate
	$("#reset").click(function () {
		$('#doctor_register_form')[0].reset();
	 });
	
	
	//postal code validate
	function zipvalid6(){
		var phn = $('#d_postalcode').val();
		if (phn.length <6)//Condition to check textbox contains 6 numbers or not
		{ 
			alert("Enter 6 digit number."); 
			$('#d_postalcode').focus(); 
			return true; 
		}
	}
	
	var base64url = '';
	
	function EL(id) { return document.getElementById(id); } // Get el by ID helper function

    function readFile() {
        if (this.files && this.files[0]) {
			$('#sampleimg').hide();
			$('#photo_error').hide();
			$('#img').show();
            var FR= new FileReader();
            FR.onload = function(e) {
                EL("img").src = e.target.result;
                base64url = e.target.result;
            };
            FR.readAsDataURL( this.files[0] );
        }
    }
    EL("photoimg").addEventListener("change", readFile, false);
	
	var first_visit_val= '';
	$("input:radio").click(function(){							
		if( $(this).is(":checked") ){
			first_visit_val = $(this).val();			
		}
	});						
						
	$('#nextbutton').click(function(){	

	$('#doctor_profile_details').validate({
		errorElement: 'span', 
		errorClass: 'error', 
		focusInvalid: false, 
		ignore: "",
		rules: {
			d_firstname: {
				required: true
			},
			d_emailaddress: {
				required: true
			},
			d_mobileno: {
				required: true
			}
		},

		invalidHandler: function (event, validator) {
			//display error alert on form submit    
		},

		errorPlacement: function (error, element) { // render error placement for each input type
			var icon = $(element).parent('.input-with-icon').children('i');
			var parent = $(element).parent('.input-with-icon');
			icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  
			parent.removeClass('success-control').addClass('error-control');  
		},

		highlight: function (element) { // hightlight error inputs
			var parent = $(element).parent();
			parent.removeClass('success-control').addClass('error-control'); 
		},

		unhighlight: function (element) { // revert the change done by hightlight
			
		},

		success: function (label, element) {
			var icon = $(element).parent('.input-with-icon').children('i');
			var parent = $(element).parent('.input-with-icon');
			icon.removeClass("fa fa-exclamation").addClass('fa fa-check-circle');
			parent.removeClass('error-control').addClass('success-control'); 
		},

		submitHandler: function (form) {	
			var image_exists = $('#img').attr('src');
			var profileImage = $('#photoimg');
			
			if(image_exists == null || image_exists == '') {
				if ($.trim(profileImage.val()) == '') {
					profileImage.addClass('errorBorder');
					$(".photo_error").show();
					$(".photo_error").html("Select Profile Photo");
					profileImage.focus();
					error = true;
				}
				if ($.trim(profileImage.val()) != '') {
					profileImage.removeClass('errorBorder');
					$(".photo_error").hide();
					error = false;
				}
			}
			
			if(image_exists != ''){
				base64url = image_exists;
			
			
				var data = {
						p_uid : $('#p_uid').val(),
						p_fname : $('#p_fname').val(),
						p_mname : $('#p_mname').val(),
						p_lname : $('#p_lname').val(),
						p_gender : $('#p_gender').val(),
						p_dob : $('#p_dob').val(),
						form1Email : $('#p_email').val(),
						p_address : $('#p_address').val(),
						p_city : $('#p_city').val(),
						p_state : $('#state_id').val(),
						p_country : $('#country_id').val(),
						p_postalcode : $('#p_postalcode').val(),
						p_phone : $('#p_phone').val(),
						add_patient_man : $('#add_patient_man').val(),
						profile : base64url							
					};
					
				$('#add_new_patient').attr('disabled', 'disabled').css({"opacity": "0.3","cursor": "none"});	
				$.ajax({
						type: "POST",
						url: "functions.php",
						data: data,
						success:function(result)
						{
							$("#confirmation").html(result).css({"font-size": "150%","text-align": "center", "color": "green", "margin": "5px"}).fadeOut(3000);
							$(".page-content").hide('slide', {direction: 'left' }, 4000);
							
						},
						error: function ()
						{
						}
				}); 
			}
		}
   
	});
	});
			