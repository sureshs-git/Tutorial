$(document).ready(function(){
		
//Phone number validate
	function validatemobile(key)
	{
		//getting key code of pressed key
		var keycode = (key.which) ? key.which : key.keyCode;
		//comparing pressed keycodes
		if (!(keycode==8 || keycode==46)&&(keycode < 48 || keycode > 57))
		{
		alert("Please Type Numbers Only.");
		return false;
		}
	}
	
	
	
	//Field validate
	$('#p_basic_profile').validate({
                errorElement: 'span', 
                errorClass: 'error', 
                focusInvalid: false, 
                ignore: "",
                rules: {
                    p_fname: {
                        required: true
                    },
					p_gender: {
                        required: true
                    },
					p_dob: {
                        required: true
                    },
					p_phone: {
                        required: true
                    },
					p_address: {
                        required: true
                    },
					p_city: {
                        required: true
                    },
					country_id: {
                        required: true
                    },
					state_id: {
                        required: true
                    },
					p_postalcode: {
                        required: true
                    },
                    form1Email: {
                        required: true,
                        email: true
                    },
                    form1Url: {
                        required: true,
                        url: true
                    },
                    gendericonic:{
                        required: true
                    }
                },

                invalidHandler: function (event, validator) {
					//display error alert on form submit    
                },

                errorPlacement: function (error, element) { // render error placement for each input type
                    var icon = $(element).parent('.input-with-icon').children('i');
                    var parent = $(element).parent('.input-with-icon');
                    icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  
                    parent.removeClass('success-control').addClass('error-control');  
                },

                highlight: function (element) { // hightlight error inputs
					var parent = $(element).parent();
                    parent.removeClass('success-control').addClass('error-control'); 
                },

                unhighlight: function (element) { // revert the change done by hightlight
                    
                },

                success: function (label, element) {
                    var icon = $(element).parent('.input-with-icon').children('i');
					var parent = $(element).parent('.input-with-icon');
                    icon.removeClass("fa fa-exclamation").addClass('fa fa-check-circle');
					parent.removeClass('error-control').addClass('success-control'); 
                },

                submitHandler: function (form) {
                
                }
           
            });
             $('.select2', "#p_basic_profile").change(function () {
                $('#p_basic_profile').validate().element($(this)); //revalidate the chosen dropdown value and show error or success message for the input
            });
});