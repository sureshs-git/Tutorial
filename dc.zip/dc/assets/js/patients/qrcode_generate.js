function getemail(val) {
		$.ajax({ 
		type: "POST",
		url: "qrcode.php",
		data:{ uid : $("#p_uid").val(), title : $("#p_title").val(), fname : $("#p_fname").val(), mname : $("#p_mname").val(), lname : $("#p_lname").val(), gender : $("#p_gender").val(), dob : $("#p_dob").val(), ccode : $("#p_ccode").val(), phone : $("#p_phone").val(), address : $("#p_address").val(), city : $("#p_city").val(), state : $("#state_id").val(), country : $("#country_id").val(), postcode : $("#p_postalcode").val(), email : $("#p_email").val() },
		success: function(data){
			$("#qrcode").html(data);
		}
		});
	}