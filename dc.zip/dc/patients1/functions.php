<?php
ob_start();
session_start(); 
error_reporting(E_ALL & ~E_NOTICE);
include '../db_connection/db.php';
if($_REQUEST['key'] == 'logout')
{
    session_destroy(); 
    header("Location:../index.php");
}
if($_POST['add_patient1'] == 'add_patient1')
{
	echo '<pre>';
	print_R($_POST);
	die;
    mysqli_query($conn, "INSERT INTO patient_details (name) VALUES ('".mysqli_real_escape_string($conn, $_POST['name'])."')");
    $add_team = mysqli_insert_id($conn);
	echo "Team name added!";
    echo '<script type="text/javascript">setTimeout(function(){window.top.location="add-team.php"} , 4000);</script>';
    
}
//Getting state from country selection
if(!empty($_POST["country_id"])) {	
	$sql ="SELECT * FROM state WHERE country_id = '" . $_POST["country_id"] . "'";
	$results = $conn->query($sql);
?>
	<option value="">Select State</option>
<?php	foreach($results as $state) { ?>
	<option value="<?php echo $state["state_id"]; ?>"><?php echo $state["state"]; ?></option>
<?php
	}
}
//Getting patient name from UID in advance tab
if(!empty($_POST["uid_advance"])) {	
$sql ="SELECT p_fname FROM patient_details WHERE p_uid = '" . $_POST["uid_advance"] . "'";
$name=$conn->query($sql);
$row = mysqli_fetch_assoc($name);
$pname=$row['p_fname'];
?>
<input name="p_name" id="p_name" type="text"  class="form-control" value="<?php echo $row['p_fname']; ?>" readonly>
<?php	
}

if($_POST['add_patient_man'] == 'add_patient_man')
{
	$profilephoto = $_POST['profile'];
	$_POST['p_dob'] = date("Y-m-d", strtotime($_POST['p_dob']));
	$query = mysqli_query($conn, "INSERT INTO patient_details (p_uid, p_fname, p_mname, p_lname, p_gender, p_dob, p_email, p_address, p_city, p_state, p_country, p_postalcode, p_phone) VALUES ('".$_POST['p_uid']."', '".mysqli_real_escape_string($conn, $_POST['p_fname'])."', '".$_POST['p_mname']."', '".mysqli_real_escape_string($conn, $_POST['p_lname'])."', '".$_POST['p_gender']."', '".$_POST['p_dob']."', '".$_POST['form1Email']."', '".$_POST['p_address']."', '".$_POST['p_city']."', '".$_POST['p_state']."', '".$_POST['p_country']."', '".$_POST['p_postalcode']."', '".$_POST['p_phone']."')") or die(mysqli_error($conn));
	if($query) {	
		$last_insert_id = mysqli_insert_id($conn);
        $userId = $last_insert_id;
		//$employeePhoto = base64_to_jpeg($_POST['profile'], '../assets/img/user/'.$userId.'-employeePhoto.jpg');
		if(1){
			echo "Patient details saved !";
			echo '<script type="text/javascript">setTimeout(function(){window.top.location="patients_list.php"} , 3000);</script>';
		}
	}
}

?>