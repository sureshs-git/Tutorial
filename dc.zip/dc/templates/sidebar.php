<div class="page-sidebar" id="main-menu">
    <!-- BEGIN MINI-PROFILE -->
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <!-- END MINI-PROFILE -->
      <!-- BEGIN SIDEBAR MENU -->
      <!--<p class="menu-title">BROWSE <span class="pull-right"><a href="javascript:;"><i class="fa fa-refresh"></i></a></span></p>-->
      <ul>
        <li class="start "> <a href="#" > <i class="fa fa-wheelchair"></i> <span class="title">PATIENTS</span> <span class="selected"></span> <span class="arrow open"></span> </a> 
		    <ul class="sub-menu">
				<!--<li > <a href="dashboard_v1.html"> Dashboard v1 </a> </li>
				<li class="active"> <a href="index.html "> Dashboard v2 <span class=" label label-info pull-right m-r-30">NEW</span></a></li>-->
				<li > <a href="../patients/add_patient.php"> Register / Add New</a> </li>
				<li > <a href="../patients/patients_list.php"> Overall List </a> </li>
				<li > <a href="../patients/all_in_one.php"> All in One </a> </li>
				<li > <a href="#"> Prescription Bill </a> </li>
				<li > <a href="../patients/patient_history.php"> Patient History </a> </li>
				<li > <a href="#"> Clinical Examination </a> </li>
				<li > <a href="#"> Photographs & X-rays </a> </li>
				<li > <a href="#"> Videos </a> </li>
				<li > <a href="#"> Lab Work </a> </li>
				<li > <a href="#"> Lab Work update </a> </li>
				<li > <a href="#"> Reception </a> </li>
			</ul>
		</li>
        
        <li class=""> <a href="javascript:;"> <i class="fa fa-user-md"></i> <span class="title">DOCTORS</span> <span class="arrow open"></span> </a>
            <ul class="sub-menu">
              <li > <a href="../doctor/doctor_register.php"> Doctor Details </a> </li>
			  <li > <a href="../doctor/all_doctors.php"> Doctor Consulting Details </a> </li>
			  <li > <a href="#"> Doctor Leave Details </a> </li>
			  <li > <a href="#"> Operatory </a> </li>
			  <li > <a href="#"> <span class="title">Scheduler</span> <span class="arrow "></span>
			    <ul class="sub-menu">
					<li > <a href="#"> Operatory Wise </a> </li>
					<li > <a href="#"> Doctor Wise </a> </li>
                </ul>
			  <li > <a href="#"> Patients in "Q" </a> </li>
            </ul>
        </li>  
        <li class=""> <a href="javascript:;"> <i class="fa fa-stethoscope"></i> <span class="title">MASTER</span> <span class="arrow "></span> </a>
            <ul class="sub-menu">
              <li > <a href="#"> Diagnosis/Treatment </a> </li>
              <li > <a href="#"> Drugs</a> </li>
			  <li > <a href="#"> Make Patient Q</a> </li>
			  <li > <a href="#"> Prescription Report Writer</a> </li>
			  <li > <a href="#"> prescription Template</a> </li>
			  <li > <a href="#"> Patient Category</a> </li>
			  <li > <a href="#"> Reference</a> </li>
			  <li > <a href="#"> Contacts</a> </li>
			  <li > <a href="#"> Phonebook</a> </li>
			  <li > <a href="#"> Employee</a> </li>
			  <li > <a href="#"> Employee Leave</a> </li>
			  <li > <a href="#"> <span class="title">Inventory</span> <span class="arrow "></span>
			    <ul class="sub-menu">
					<li > <a href="#"> Units </a> </li>
					<li > <a href="#"> Product </a> </li>
					<li > <a href="#"> Supplier </a> </li>
                </ul>
			  <li > <a href="#"> Lab Details</a> </li>
			  <li > <a href="#"> Users</a> </li>
			  <li > <a href="#"> Master Key</a> </li>
			  <li > <a href="#"> Additional Questions</a> </li>
			  <li > <a href="#"> Account Head</a> </li>
			  <li > <a href="#"> Frequency</a> </li>
            </ul>
        </li>              
        <li class=""> <a href="javascript:;"> <i class="icon-custom-ui"></i> <span class="title">CONFIGURATIONS</span> <span class="arrow "></span> </a>
          <ul class="sub-menu">
            <li > <a href="#"> Access Right</a> </li>
			<li > <a href="#"> Backup Disk</a> </li>
			<li > <a href="#"> Clinical Configurations</a> </li>
			<li > <a href="#"> Create Reference Letter</a> </li>
			<li > <a href="#"> Reminders</a> </li>
			<li > <a href="#"> Scanning</a> </li>
			<li > <a href="#"> Send SMS</a> </li>
			<li > <a href="#"> SMS Templates</a> </li>
			<li > <a href="#"> SMS Configurations</a> </li>
			<li > <a href="#"> Automated SMS Configurations</a> </li>
			<li > <a href="#"> SMS Report</a> </li>
			<li > <a href="#"> SMS Balance</a> </li>
			<li > <a href="#"> SMTP Host Configurations</a> </li>
			<li > <a href="#"> Send Mail</a> </li>
			<li > <a href="#"> Chat</a> </li>
          </ul>
        </li>
        <li class=""> <a href="javascript:;"> <i class="icon-custom-form"></i> <span class="title">ACCOUNTS</span> <span class="arrow "></span> </a>
          <ul class="sub-menu">
            <li > <a href="../accounts/income_expense.php"> Income & Expenses</a> </li>
			<li > <a href="#"> Profit & Loss</a> </li>
			<li > <a href="#"> <span class="title">Inventory</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="../accounts/purchase.php"> Purchase </a> </li>
					<li > <a href="#"> Payment </a> </li>
					<li > <a href="../accounts/consumption.php"> Consumption </a> </li>
                </ul>
			<li > <a href="#"> Laboratory Payment</a> </li>
          </ul>
        </li>
        <li class=""> <a href="javascript:;"> <i class="icon-custom-portlets"></i> <span class="title">REPORTS</span> <span class="arrow "></span> </a>
          <ul class="sub-menu">
            <li > <a href="#"> Accounts</a> </li>
			<li > <a href="#"> <span class="title"> Appointment</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Appointment </a> </li>
					<li > <a href="#"> Weekly Appointment </a> </li>
                </ul>
			<li > <a href="#"> <span class="title"> Doctor</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Doctor </a> </li>
					<li > <a href="#"> Collection </a> </li>
					<li > <a href="#"> Doctor Leave </a> </li>
					<li > <a href="#"> Referred Patient </a> </li>
                </ul>
			<li > <a href="#"> <span class="title"> Patient</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Patient </a> </li>
					<li > <a href="#"> Patient Category Report </a> </li>
					<li > <a href="#"> New Patients </a> </li>
					<li > <a href="#"> Recall </a> </li>
					<li > <a href="#"> Notes/Chief Compliant </a> </li>
					<li > <a href="#"> Clinical Examination </a> </li>
					<li > <a href="#"> Patient History </a> </li>
                </ul>
			<li > <a href="#"> <span class="title"> Inventory</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Purchase Report </a> </li>
					<li > <a href="#"> Consumption Report </a> </li>
					<li > <a href="#"> Payment Report </a> </li>
					<li > <a href="#"> Stock Report </a> </li>
                </ul>
			<li > <a href="#"> <span class="title"> Certificates</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Reference </a> </li>
					<li > <a href="#"> Dental Fitness Certificate </a> </li>
					<li > <a href="#"> Medical Certificate </a> </li>
					<li > <a href="#"> Consent Form </a> </li>
					<li > <a href="#"> Thanks Letter </a> </li>
					<li > <a href="#"> Reference Letter </a> </li>
                </ul>
			<li > <a href="#"> <span class="title">Treatment All</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Treatment </a> </li>
					<li > <a href="#"> Yearly Treatment Details </a> </li>
                </ul>
			<li > <a href="#"> <span class="title">Lab</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Laboratory Payment </a> </li>
					<li > <a href="#"> Laboratory Work </a> </li>
                </ul>
			<li > <a href="#"> <span class="title">Miscellaneous Reports</span> <span class="arrow "></span>
				<ul class="sub-menu">
					<li > <a href="#"> Receipt Type </a> </li>
					<li > <a href="#"> Outstanding </a> </li>
					<li > <a href="#"> Contacts </a> </li>
					<li > <a href="#"> Employee </a> </li>
					<li > <a href="#"> Drugs </a> </li>
					<li > <a href="#"> Users </a> </li>					
                </ul>
            </ul>
			</li>
      </ul>
      <div class="clearfix"></div>
      <!-- END SIDEBAR MENU -->
    </div>
  </div>