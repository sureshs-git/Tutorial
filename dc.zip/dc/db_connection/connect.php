<?php 
session_start();
error_reporting(E_ALL & ~E_NOTICE);
include('db.php');
/* These are our valid username and passwords */
if (isset($_POST['email']) && isset($_POST['password'])) {
$result = mysqli_query($conn, "SELECT * FROM users WHERE email='" . $_POST["email"] . "' and password = '". $_POST["password"]."'");
if($row  = mysqli_fetch_array($result))
{
    
    if(is_array($row)) {
    $_SESSION["user_id"] = $row[user_id];
    $_SESSION["f_name"] = $row[f_name];
    $_SESSION["l_name"] = $row[l_name];
	$_SESSION["admin"] = $row[f_name];
	$_SESSION["user"] = $row[f_name];
	}
	    
		if($_POST["email"]=='admin@myiqds.com') { 
		echo '<p style="color: red;">Login Successful!</p>';
		echo '<script type="text/javascript">setTimeout(function(){window.top.location="dashboard/dashboard.php"} , 3000);</script>';
		}else{
		if(isset($_SESSION["user_id"])) { 
			echo '<p style="color: green;">Login Successful!</p>';
			echo '<script type="text/javascript">setTimeout(function(){window.top.location="dashboard/dashboard/dashboard.php"} , 3000);</script>';
			}
		}
		if ($_POST['cookie'] == 1) { 
		//if (isset($_POST['remember']) && $_POST['remember'] == 'on') { 
            /* Set cookie to last 1 year */
            setcookie("email", $_POST["email"], time()+(60*60*24*365));
            setcookie("password", $_POST["password"], time()+(60*60*24*365));
        } else {
            /* Cookie expires when browser closes */
            setcookie("email", $_POST["email"], time()-1);
            setcookie("password", $_POST["password"], time()-1);
        } 
}else 	{
		echo '<p style="color: red;font-size:17px;">Invalid Username or password!</p>';	
		echo '<script type="text/javascript">setTimeout(function(){window.top.location="index.php"} , 4000);</script>';
		}
}	$username = '';
	$password = '';

  if (isset($_COOKIE['email'])) {
    $username = $_COOKIE['email'];
  }

  if (isset($_COOKIE['password'])) {
    $password = $_COOKIE['password'];
  }	
?>